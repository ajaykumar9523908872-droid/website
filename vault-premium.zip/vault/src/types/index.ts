// ═══════════════════════════════════════════════════════════════════
// VAULT — Shared TypeScript Types
// ═══════════════════════════════════════════════════════════════════

export type ContentType = 'image' | 'video';
export type ContentStatus = 'draft' | 'published' | 'archived';
export type TransactionType = 'recharge' | 'unlock' | 'refund' | 'bonus';
export type PaymentStatus = 'pending' | 'succeeded' | 'failed' | 'refunded';

// ─── Database Row Types ───────────────────────────────────────────

export interface User {
  id: string;
  clerk_id: string;
  email: string;
  username: string | null;
  display_name: string | null;
  avatar_url: string | null;
  is_admin: boolean;
  is_banned: boolean;
  created_at: string;
  updated_at: string;
  last_seen_at: string | null;
}

export interface Wallet {
  id: string;
  user_id: string;
  balance: number;
  lifetime_spent: number;
  lifetime_added: number;
  created_at: string;
  updated_at: string;
}

export interface WalletTransaction {
  id: string;
  wallet_id: string;
  user_id: string;
  type: TransactionType;
  amount: number;
  balance_before: number;
  balance_after: number;
  description: string | null;
  reference_id: string | null;
  created_at: string;
}

export interface Payment {
  id: string;
  user_id: string;
  stripe_payment_intent: string;
  stripe_session_id: string | null;
  amount_eur_cents: number;
  coins_purchased: number;
  status: PaymentStatus;
  metadata: Record<string, unknown>;
  created_at: string;
  updated_at: string;
}

export interface Content {
  id: string;
  type: ContentType;
  status: ContentStatus;
  title: string;
  description: string | null;
  coin_price: number;
  is_featured: boolean;
  is_premium: boolean;
  storage_key: string | null;
  thumbnail_key: string | null;
  blur_hash: string | null;
  file_size_bytes: number | null;
  dimensions: { width: number; height: number } | null;
  mux_asset_id: string | null;
  mux_playback_id: string | null;
  mux_playback_id_signed: string | null;
  duration_seconds: number | null;
  unlock_count: number;
  view_count: number;
  tags: string[];
  sort_order: number;
  created_at: string;
  updated_at: string;
}

export interface UnlockedContent {
  id: string;
  user_id: string;
  content_id: string;
  coins_spent: number;
  unlocked_at: string;
  last_viewed_at: string | null;
  view_count: number;
}

// ─── API Response Types ───────────────────────────────────────────

export interface ContentWithUnlock extends Content {
  is_unlocked: boolean;
  unlocked_at: string | null;
  thumbnail_url: string | null;
}

export interface RechargePackage {
  coins: number;
  price_cents: number;
  label: string;
  badge?: string;
}

// ─── API Request / Response ───────────────────────────────────────

export interface UnlockRequest {
  contentId: string;
}

export interface UnlockResponse {
  success: boolean;
  newBalance?: number;
  error?: string;
  requiresRecharge?: boolean;
}

export interface RechargeRequest {
  packageIndex: number;
  customCoins?: number;
}

export interface RechargeResponse {
  checkoutUrl: string;
}

// ─── Admin ────────────────────────────────────────────────────────

export interface AdminStats {
  totalUsers: number;
  totalRevenueCents: number;
  totalUnlocks: number;
  totalContent: number;
  recentPayments: Payment[];
  topContent: Array<Content & { total_coins_earned: number }>;
}

export interface UploadContentRequest {
  title: string;
  description?: string;
  coinPrice: number;
  type: ContentType;
  isFeatured?: boolean;
  isPremium?: boolean;
  tags?: string[];
}

// ─── UI State ─────────────────────────────────────────────────────

export interface FilterState {
  type: 'all' | 'image' | 'video';
  sort: 'newest' | 'popular' | 'price_asc' | 'price_desc';
  premium: boolean;
}

export interface ToastMessage {
  id: string;
  type: 'success' | 'error' | 'info' | 'warning';
  title: string;
  description?: string;
}

// ─── Supabase helpers ─────────────────────────────────────────────

export type Database = {
  public: {
    Tables: {
      users: { Row: User; Insert: Partial<User>; Update: Partial<User> };
      wallet: { Row: Wallet; Insert: Partial<Wallet>; Update: Partial<Wallet> };
      wallet_transactions: { Row: WalletTransaction };
      payments: { Row: Payment; Insert: Partial<Payment>; Update: Partial<Payment> };
      content: { Row: Content; Insert: Partial<Content>; Update: Partial<Content> };
      unlocked_content: { Row: UnlockedContent; Insert: Partial<UnlockedContent> };
      analytics: {
        Row: { id: string; event: string; content_id: string | null; user_id: string | null; created_at: string };
        Insert: { event: string; content_id?: string; user_id?: string; metadata?: Record<string, unknown> };
      };
    };
    Functions: {
      deduct_coins: {
        Args: { p_user_id: string; p_amount: number; p_content_id: string; p_description: string };
        Returns: { success: boolean; new_balance: number; error: string | null }[];
      };
      add_coins: {
        Args: { p_user_id: string; p_amount: number; p_payment_id: string; p_description: string };
        Returns: { success: boolean; new_balance: number }[];
      };
    };
  };
};
