import Link from 'next/link';
import { ArrowRight, Play, Image, Lock, Coins, Zap, Shield } from 'lucide-react';
import SiteLayout from '@/components/layout/SiteLayout';
import ContentCard from '@/components/media/ContentCard';
import { createServerSupabase } from '@/lib/supabase';
import type { ContentWithUnlock } from '@/types';

async function getFeaturedContent(): Promise<ContentWithUnlock[]> {
  const supabase = createServerSupabase();
  const { data } = await supabase
    .from('content')
    .select('*')
    .eq('status', 'published')
    .eq('is_featured', true)
    .order('created_at', { ascending: false })
    .limit(8);

  return (data ?? []).map((item) => ({
    ...item,
    is_unlocked: false,
    unlocked_at: null,
    thumbnail_url: null,
  }));
}

async function getTrendingContent(): Promise<ContentWithUnlock[]> {
  const supabase = createServerSupabase();
  const { data } = await supabase
    .from('content')
    .select('*')
    .eq('status', 'published')
    .order('unlock_count', { ascending: false })
    .limit(6);

  return (data ?? []).map((item) => ({
    ...item,
    is_unlocked: false,
    unlocked_at: null,
    thumbnail_url: null,
  }));
}

export default async function HomePage() {
  const [featured, trending] = await Promise.all([
    getFeaturedContent(),
    getTrendingContent(),
  ]);

  return (
    <SiteLayout>
      {/* ─── Hero ─────────────────────────────────────────────── */}
      <section className="relative min-h-[90vh] flex items-center justify-center overflow-hidden">
        {/* Radial glow background */}
        <div className="absolute inset-0 bg-hero-radial pointer-events-none" />

        {/* Animated grain */}
        <div className="absolute inset-0 opacity-30 pointer-events-none"
          style={{
            backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 400 400' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.85' numOctaves='4'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)' opacity='0.06'/%3E%3C/svg%3E")`,
          }}
        />

        {/* Gold decorative lines */}
        <div className="absolute top-1/4 left-0 w-[1px] h-32 bg-gradient-to-b from-transparent via-gold/30 to-transparent" />
        <div className="absolute top-1/3 right-0 w-[1px] h-48 bg-gradient-to-b from-transparent via-gold/20 to-transparent" />

        <div className="relative z-10 text-center px-4 max-w-5xl mx-auto">
          {/* Pre-label */}
          <div className="inline-flex items-center gap-2 badge-gold mb-8 animate-fade-in">
            <span className="w-1.5 h-1.5 bg-gold rounded-full animate-pulse" />
            Exclusive Premium Content
          </div>

          {/* Main headline */}
          <h1 className="font-display text-5xl sm:text-7xl md:text-8xl font-light leading-[1.05] mb-6 animate-fade-up">
            <span className="text-white">Premium Content,</span>
            <br />
            <span className="text-gold-gradient italic">Unlocked.</span>
          </h1>

          <p className="text-[#A0A0A0] text-lg sm:text-xl max-w-2xl mx-auto mb-12 leading-relaxed animate-fade-up"
            style={{ animationDelay: '0.1s' }}>
            Browse exclusive images and videos. Recharge your wallet and unlock
            content instantly — no subscription, no commitment.
          </p>

          {/* CTAs */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 animate-fade-up"
            style={{ animationDelay: '0.2s' }}>
            <Link
              href="/explore"
              className="btn-gold flex items-center gap-2 text-black font-semibold px-8 py-4 rounded-full text-base w-full sm:w-auto justify-center"
            >
              Browse Content
              <ArrowRight size={18} />
            </Link>
            <Link
              href="/wallet"
              className="flex items-center gap-2 bg-[#111111] border border-[#262626] hover:border-gold/30 text-white font-medium px-8 py-4 rounded-full text-base transition-all duration-300 w-full sm:w-auto justify-center"
            >
              <Coins size={18} className="text-gold" />
              Get Coins
            </Link>
          </div>

          {/* Stats */}
          <div className="flex items-center justify-center gap-8 mt-16 pt-8 border-t border-[#1a1a1a] animate-fade-in"
            style={{ animationDelay: '0.4s' }}>
            {[
              { value: `${featured.length}+`, label: 'Exclusive Items' },
              { value: '100%', label: 'Premium Quality' },
              { value: '€0', label: 'No Subscription' },
            ].map(({ value, label }) => (
              <div key={label} className="text-center">
                <div className="font-display text-2xl text-white font-medium">{value}</div>
                <div className="text-xs text-[#5A5A5A] mt-0.5 tracking-wide uppercase">{label}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Scroll indicator */}
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 opacity-40">
          <div className="w-[1px] h-8 bg-gradient-to-b from-white to-transparent animate-float" />
        </div>
      </section>

      {/* ─── Featured Content ────────────────────────────────── */}
      {featured.length > 0 && (
        <section className="py-20 px-4">
          <div className="max-w-7xl mx-auto">
            <SectionHeader
              label="Featured"
              title="Hand-Picked Exclusives"
              action={{ label: 'View All', href: '/explore?filter=featured' }}
            />
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 mt-10">
              {featured.map((item, i) => (
                <ContentCard
                  key={item.id}
                  content={item}
                  priority={i < 4}
                  style={{ animationDelay: `${i * 0.05}s` }}
                />
              ))}
            </div>
          </div>
        </section>
      )}

      {/* ─── How It Works ────────────────────────────────────── */}
      <section className="py-20 px-4 bg-[#0d0d0d]">
        <div className="max-w-5xl mx-auto">
          <SectionHeader
            label="Simple"
            title="How VAULT Works"
            centered
          />
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-12">
            {[
              {
                icon: Coins,
                step: '01',
                title: 'Recharge Wallet',
                description: 'Add coins to your wallet. 100 coins = €1. No subscription required.',
              },
              {
                icon: Lock,
                step: '02',
                title: 'Browse & Unlock',
                description: 'Browse premium content and tap unlock on anything you want. Coins deducted instantly.',
              },
              {
                icon: Zap,
                step: '03',
                title: 'Access Forever',
                description: 'Once unlocked, content is yours permanently. Watch and view anytime.',
              },
            ].map(({ icon: Icon, step, title, description }) => (
              <div
                key={step}
                className="vault-card p-8 group"
              >
                <div className="flex items-start justify-between mb-6">
                  <div className="w-12 h-12 rounded-2xl bg-gold-muted border border-gold/20 flex items-center justify-center group-hover:bg-gold/20 transition-colors duration-300">
                    <Icon size={20} className="text-gold" />
                  </div>
                  <span className="font-display text-4xl text-[#1a1a1a] font-bold select-none">
                    {step}
                  </span>
                </div>
                <h3 className="font-semibold text-white text-lg mb-2">{title}</h3>
                <p className="text-[#5A5A5A] text-sm leading-relaxed">{description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ─── Trending ─────────────────────────────────────────── */}
      {trending.length > 0 && (
        <section className="py-20 px-4">
          <div className="max-w-7xl mx-auto">
            <SectionHeader
              label="Trending"
              title="Most Unlocked"
              action={{ label: 'See All', href: '/explore?sort=popular' }}
            />
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mt-10">
              {trending.map((item, i) => (
                <ContentCard
                  key={item.id}
                  content={item}
                  style={{ animationDelay: `${i * 0.05}s` }}
                />
              ))}
            </div>
          </div>
        </section>
      )}

      {/* ─── Recharge CTA Banner ─────────────────────────────── */}
      <section className="py-20 px-4">
        <div className="max-w-4xl mx-auto">
          <div className="relative rounded-3xl overflow-hidden border border-gold/20 bg-gradient-to-br from-[#111111] to-[#0d0d0d] p-12 text-center">
            {/* Glow */}
            <div className="absolute inset-0 bg-hero-radial opacity-50" />

            <div className="relative z-10">
              <Shield size={40} className="text-gold mx-auto mb-6 animate-float" />
              <h2 className="font-display text-4xl sm:text-5xl text-white mb-4">
                Start Unlocking Today
              </h2>
              <p className="text-[#A0A0A0] text-lg mb-8 max-w-lg mx-auto">
                Recharge your wallet and get instant access to exclusive content.
                No monthly fees, pay only for what you want.
              </p>
              <Link
                href="/wallet"
                className="btn-gold inline-flex items-center gap-2 text-black font-semibold px-8 py-4 rounded-full text-base"
              >
                <Coins size={18} />
                Recharge Wallet
              </Link>
            </div>
          </div>
        </div>
      </section>
    </SiteLayout>
  );
}

// ─── Section Header Component ────────────────────────────────────
function SectionHeader({
  label,
  title,
  action,
  centered = false,
}: {
  label: string;
  title: string;
  action?: { label: string; href: string };
  centered?: boolean;
}) {
  return (
    <div className={`flex flex-col ${centered ? 'items-center text-center' : 'sm:flex-row sm:items-end sm:justify-between'} gap-4`}>
      <div className={centered ? 'text-center' : ''}>
        <span className="badge-gold block mb-3">{label}</span>
        <h2 className="font-display text-3xl sm:text-4xl font-light text-white">
          {title}
        </h2>
      </div>
      {action && (
        <Link
          href={action.href}
          className="flex items-center gap-1 text-sm text-[#A0A0A0] hover:text-gold transition-colors duration-200 shrink-0"
        >
          {action.label}
          <ArrowRight size={14} />
        </Link>
      )}
    </div>
  );
}
