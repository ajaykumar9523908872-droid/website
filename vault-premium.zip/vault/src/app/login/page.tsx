import { SignIn } from '@clerk/nextjs';
import { Crown } from 'lucide-react';
import type { Metadata } from 'next';

export const metadata: Metadata = { title: 'Sign In' };

export default function LoginPage() {
  return (
    <div className="min-h-screen bg-background flex items-center justify-center px-4 relative overflow-hidden">
      {/* Background glow */}
      <div className="absolute inset-0 bg-hero-radial opacity-50 pointer-events-none" />

      <div className="relative z-10 w-full max-w-md">
        {/* Logo */}
        <div className="text-center mb-10">
          <div className="flex items-center justify-center gap-2 mb-2">
            <Crown size={22} className="text-gold" />
            <span className="font-display text-2xl tracking-[0.25em] text-white">VAULT</span>
          </div>
          <p className="text-[#5A5A5A] text-sm">Sign in to access premium content</p>
        </div>

        <SignIn
          appearance={{
            variables: {
              colorBackground: '#111111',
              colorInputBackground: '#0d0d0d',
              colorInputText: '#ffffff',
              colorText: '#ffffff',
              colorTextSecondary: '#A0A0A0',
              colorPrimary: '#D4AF37',
              colorDanger: '#ef4444',
              borderRadius: '16px',
              fontFamily: 'Outfit, system-ui, sans-serif',
            },
            elements: {
              card: 'bg-[#111111] border border-[#262626] shadow-card',
              headerTitle: 'font-display text-white text-2xl font-light',
              headerSubtitle: 'text-[#A0A0A0] text-sm',
              formButtonPrimary: 'bg-gold text-black font-semibold hover:bg-gold-light rounded-2xl',
              formFieldInput: 'bg-[#0d0d0d] border-[#262626] text-white rounded-xl',
              formFieldLabel: 'text-[#A0A0A0] text-xs uppercase tracking-wide',
              footerActionLink: 'text-gold hover:text-gold-light',
              dividerLine: 'bg-[#262626]',
              dividerText: 'text-[#5A5A5A]',
              socialButtonsBlockButton: 'border-[#262626] bg-[#0d0d0d] text-white hover:bg-[#1a1a1a] rounded-xl',
              identityPreviewEditButton: 'text-gold',
            },
          }}
        />
      </div>
    </div>
  );
}
