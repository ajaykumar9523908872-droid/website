import { notFound } from 'next/navigation';
import type { Metadata } from 'next';
import { currentUser } from '@clerk/nextjs/server';
import { supabaseAdmin, getUserByClerkId } from '@/lib/supabase';
import SiteLayout from '@/components/layout/SiteLayout';
import ContentViewer from '@/components/media/ContentViewer';
import UnlockButton from '@/components/media/UnlockButton';
import { formatCoins, formatDate } from '@/lib/utils';
import { Calendar, Eye, Coins, Crown, Tag } from 'lucide-react';

interface ContentPageProps {
  params: { id: string };
}

export async function generateMetadata({ params }: ContentPageProps): Promise<Metadata> {
  const { data: content } = await supabaseAdmin
    .from('content')
    .select('title, description')
    .eq('id', params.id)
    .eq('status', 'published')
    .single();

  if (!content) return { title: 'Content Not Found' };

  return {
    title: content.title,
    description: content.description ?? `Premium content on VAULT`,
  };
}

export default async function ContentPage({ params }: ContentPageProps) {
  // Fetch content
  const { data: content } = await supabaseAdmin
    .from('content')
    .select('*')
    .eq('id', params.id)
    .eq('status', 'published')
    .single();

  if (!content) notFound();

  // Check if user has unlocked this
  const clerkUser = await currentUser();
  let isUnlocked = false;
  let walletBalance = 0;
  let dbUserId: string | null = null;

  if (clerkUser) {
    const dbUser = await getUserByClerkId(clerkUser.id);
    if (dbUser) {
      dbUserId = dbUser.id;

      const [{ data: unlock }, { data: wallet }] = await Promise.all([
        supabaseAdmin
          .from('unlocked_content')
          .select('id')
          .eq('user_id', dbUser.id)
          .eq('content_id', params.id)
          .single(),
        supabaseAdmin
          .from('wallet')
          .select('balance')
          .eq('user_id', dbUser.id)
          .single(),
      ]);

      isUnlocked = !!unlock;
      walletBalance = wallet?.balance ?? 0;

      // Track view
      await supabaseAdmin.from('analytics').insert({
        event: 'content_view',
        content_id: params.id,
        user_id: dbUser.id,
      });
    }
  }

  // Get signed URL only if unlocked
  let mediaUrl: string | null = null;
  if (isUnlocked && content.storage_key) {
    const { getSignedReadUrl } = await import('@/lib/r2');
    mediaUrl = await getSignedReadUrl(content.storage_key, 7200); // 2 hours
  }

  return (
    <SiteLayout walletBalance={walletBalance}>
      <div className="max-w-6xl mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-[1fr_340px] gap-8">
          {/* ─── Media Viewer ─── */}
          <div>
            <ContentViewer
              content={content}
              isUnlocked={isUnlocked}
              mediaUrl={mediaUrl}
            />
          </div>

          {/* ─── Sidebar ─── */}
          <div className="space-y-6">
            {/* Title & Tags */}
            <div>
              {content.is_premium && (
                <div className="badge-gold inline-flex items-center gap-1.5 mb-4">
                  <Crown size={10} />
                  PREMIUM
                </div>
              )}
              <h1 className="font-display text-3xl sm:text-4xl font-light text-white leading-tight mb-4">
                {content.title}
              </h1>
              {content.description && (
                <p className="text-[#A0A0A0] text-sm leading-relaxed">
                  {content.description}
                </p>
              )}
            </div>

            {/* Meta */}
            <div className="space-y-3 border-t border-[#1a1a1a] pt-4">
              <MetaRow icon={Calendar} label="Published">
                {formatDate(content.created_at)}
              </MetaRow>
              <MetaRow icon={Eye} label="Unlocks">
                {content.unlock_count.toLocaleString()} times unlocked
              </MetaRow>
              {content.tags.length > 0 && (
                <MetaRow icon={Tag} label="Tags">
                  <div className="flex flex-wrap gap-1">
                    {content.tags.map((tag) => (
                      <span
                        key={tag}
                        className="text-xs bg-[#1a1a1a] border border-[#262626] rounded-full px-2 py-0.5 text-[#A0A0A0]"
                      >
                        {tag}
                      </span>
                    ))}
                  </div>
                </MetaRow>
              )}
            </div>

            {/* Unlock / Price */}
            {!isUnlocked ? (
              <div className="vault-card p-6">
                <div className="flex items-center justify-between mb-6">
                  <div>
                    <div className="text-[#5A5A5A] text-xs uppercase tracking-wide mb-1">
                      Price
                    </div>
                    <div className="flex items-center gap-2">
                      <Coins size={18} className="text-gold" />
                      <span className="font-display text-3xl text-gold font-medium">
                        {formatCoins(content.coin_price)}
                      </span>
                      <span className="text-[#5A5A5A] text-sm">coins</span>
                    </div>
                    <div className="text-[#5A5A5A] text-xs mt-1">
                      ≈ €{(content.coin_price / 100).toFixed(2)}
                    </div>
                  </div>

                  {clerkUser && (
                    <div className="text-right">
                      <div className="text-[#5A5A5A] text-xs uppercase tracking-wide mb-1">
                        Your Balance
                      </div>
                      <div className="coin-display text-lg">
                        <Coins size={14} />
                        {formatCoins(walletBalance)}
                      </div>
                    </div>
                  )}
                </div>

                <UnlockButton
                  contentId={content.id}
                  coinPrice={content.coin_price}
                  walletBalance={walletBalance}
                  isSignedIn={!!clerkUser}
                  contentTitle={content.title}
                />

                <p className="text-[#3a3a3a] text-xs text-center mt-3">
                  Permanent access after unlock
                </p>
              </div>
            ) : (
              <div className="vault-card p-6 border-gold/20">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-gold-muted border border-gold/30 flex items-center justify-center">
                    <Coins size={18} className="text-gold" />
                  </div>
                  <div>
                    <div className="text-white font-medium text-sm">Unlocked</div>
                    <div className="text-[#5A5A5A] text-xs">You have permanent access</div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </SiteLayout>
  );
}

function MetaRow({
  icon: Icon,
  label,
  children,
}: {
  icon: React.ElementType;
  label: string;
  children: React.ReactNode;
}) {
  return (
    <div className="flex items-start gap-3">
      <Icon size={14} className="text-[#5A5A5A] mt-0.5 shrink-0" />
      <div className="flex-1 min-w-0">
        <span className="text-[#5A5A5A] text-xs block">{label}</span>
        <div className="text-sm text-[#A0A0A0] mt-0.5">{children}</div>
      </div>
    </div>
  );
}
