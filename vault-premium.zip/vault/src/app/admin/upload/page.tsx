import { redirect } from 'next/navigation';
import { currentUser } from '@clerk/nextjs/server';
import { isAdmin } from '@/lib/utils';
import AdminLayout from '@/components/admin/AdminLayout';
import UploadForm from '@/components/admin/UploadForm';
import type { Metadata } from 'next';

export const metadata: Metadata = { title: 'Upload Content | Admin' };

export default async function UploadPage() {
  const clerkUser = await currentUser();
  if (!clerkUser || !isAdmin(clerkUser.id)) redirect('/');

  return (
    <AdminLayout>
      <div className="max-w-2xl">
        <div className="mb-8">
          <div className="badge-gold inline-block mb-3">Upload</div>
          <h1 className="font-display text-4xl font-light text-white">Add Content</h1>
          <p className="text-[#5A5A5A] mt-1">Upload images or videos to the vault.</p>
        </div>
        <UploadForm />
      </div>
    </AdminLayout>
  );
}
