import { redirect } from 'next/navigation';
import { currentUser } from '@clerk/nextjs/server';
import { supabaseAdmin } from '@/lib/supabase';
import type { Metadata } from 'next';
import AdminLayout from '@/components/admin/AdminLayout';
import StatCard from '@/components/admin/StatCard';
import RevenueChart from '@/components/admin/RevenueChart';
import { formatCoins, centToEuro } from '@/lib/utils';
import { Users, Coins, TrendingUp, Image, Video, Crown } from 'lucide-react';
import { isAdmin } from '@/lib/utils';

export const metadata: Metadata = { title: 'Admin Dashboard' };

export default async function AdminPage() {
  const clerkUser = await currentUser();
  if (!clerkUser || !isAdmin(clerkUser.id)) redirect('/');

  // Fetch all stats in parallel
  const [
    { count: totalUsers },
    { count: totalContent },
    { data: payments },
    { data: recentUnlocks },
    { data: topContent },
    { data: dailyRevenue },
  ] = await Promise.all([
    supabaseAdmin.from('users').select('*', { count: 'exact', head: true }),
    supabaseAdmin.from('content').select('*', { count: 'exact', head: true }).eq('status', 'published'),
    supabaseAdmin.from('payments').select('amount_eur_cents, coins_purchased').eq('status', 'succeeded'),
    supabaseAdmin.from('unlocked_content').select('id', { count: 'exact', head: true }),
    supabaseAdmin
      .from('content')
      .select('id, title, type, coin_price, unlock_count')
      .eq('status', 'published')
      .order('unlock_count', { ascending: false })
      .limit(5),
    supabaseAdmin.from('daily_revenue').select('*').limit(30),
  ]);

  const totalRevenueCents = payments?.reduce((sum, p) => sum + p.amount_eur_cents, 0) ?? 0;
  const totalCoinsIssued = payments?.reduce((sum, p) => sum + p.coins_purchased, 0) ?? 0;

  return (
    <AdminLayout>
      <div className="space-y-8">
        {/* Header */}
        <div>
          <div className="badge-gold inline-flex items-center gap-1.5 mb-3">
            <Crown size={10} />
            Admin
          </div>
          <h1 className="font-display text-4xl font-light text-white">Dashboard</h1>
          <p className="text-[#5A5A5A] mt-1">Platform overview and analytics.</p>
        </div>

        {/* Stat Cards */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <StatCard
            label="Total Revenue"
            value={`€${centToEuro(totalRevenueCents)}`}
            icon={TrendingUp}
            trend="+12% this month"
            gold
          />
          <StatCard
            label="Total Users"
            value={(totalUsers ?? 0).toLocaleString()}
            icon={Users}
            trend="Active accounts"
          />
          <StatCard
            label="Published Content"
            value={(totalContent ?? 0).toLocaleString()}
            icon={Image}
          />
          <StatCard
            label="Coins Issued"
            value={formatCoins(totalCoinsIssued)}
            icon={Coins}
          />
        </div>

        {/* Revenue Chart */}
        {dailyRevenue && dailyRevenue.length > 0 && (
          <div className="vault-card p-6">
            <h2 className="font-semibold text-white mb-6">Revenue (Last 30 Days)</h2>
            <RevenueChart data={dailyRevenue} />
          </div>
        )}

        {/* Top Content Table */}
        {topContent && topContent.length > 0 && (
          <div className="vault-card p-6">
            <h2 className="font-semibold text-white mb-6">Top Performing Content</h2>
            <div className="space-y-3">
              {topContent.map((item, i) => (
                <div
                  key={item.id}
                  className="flex items-center gap-4 p-3 rounded-xl bg-[#0d0d0d] hover:bg-[#111111] transition-colors"
                >
                  <span className="w-7 h-7 rounded-full bg-[#1a1a1a] flex items-center justify-center text-xs text-[#5A5A5A] font-mono shrink-0">
                    {i + 1}
                  </span>

                  <div className="flex-1 min-w-0">
                    <div className="text-sm font-medium text-white truncate">{item.title}</div>
                    <div className="flex items-center gap-2 mt-0.5">
                      {item.type === 'video' ? (
                        <Video size={11} className="text-[#5A5A5A]" />
                      ) : (
                        <Image size={11} className="text-[#5A5A5A]" />
                      )}
                      <span className="text-xs text-[#5A5A5A] capitalize">{item.type}</span>
                    </div>
                  </div>

                  <div className="text-right shrink-0">
                    <div className="coin-display text-sm">
                      <Coins size={11} />
                      {formatCoins(item.coin_price)}
                    </div>
                    <div className="text-xs text-[#5A5A5A] mt-0.5">
                      {item.unlock_count} unlocks
                    </div>
                  </div>

                  <div className="text-right shrink-0">
                    <div className="text-sm font-mono text-emerald-400">
                      +{formatCoins(item.coin_price * item.unlock_count)}
                    </div>
                    <div className="text-xs text-[#5A5A5A]">earned</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </AdminLayout>
  );
}
