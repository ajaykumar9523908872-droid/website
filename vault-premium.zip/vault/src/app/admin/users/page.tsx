import { redirect } from 'next/navigation';
import { currentUser } from '@clerk/nextjs/server';
import { supabaseAdmin } from '@/lib/supabase';
import { isAdmin, formatDate, formatCoins } from '@/lib/utils';
import AdminLayout from '@/components/admin/AdminLayout';
import type { Metadata } from 'next';
import { User, Coins, ShoppingBag, Ban } from 'lucide-react';

export const metadata: Metadata = { title: 'Users | Admin' };

export default async function UsersPage() {
  const clerkUser = await currentUser();
  if (!clerkUser || !isAdmin(clerkUser.id)) redirect('/');

  const { data: users } = await supabaseAdmin
    .from('users')
    .select(`
      *,
      wallet:wallet(balance, lifetime_spent, lifetime_added)
    `)
    .order('created_at', { ascending: false })
    .limit(100);

  return (
    <AdminLayout>
      <div>
        <div className="mb-8">
          <div className="badge-gold inline-block mb-3">Management</div>
          <h1 className="font-display text-4xl font-light text-white">Users</h1>
          <p className="text-[#5A5A5A] mt-1">{users?.length ?? 0} registered accounts.</p>
        </div>

        <div className="vault-card divide-y divide-[#1a1a1a]">
          {users?.map((user) => {
            const wallet = Array.isArray(user.wallet) ? user.wallet[0] : user.wallet;
            return (
              <div key={user.id} className="flex items-center gap-4 p-4 hover:bg-white/[0.02] transition-colors">
                {/* Avatar initial */}
                <div className="w-9 h-9 rounded-full bg-[#1a1a1a] border border-[#262626] flex items-center justify-center text-sm text-[#5A5A5A] shrink-0 font-medium">
                  {user.display_name?.[0]?.toUpperCase() ?? user.email[0]?.toUpperCase()}
                </div>

                {/* Info */}
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-medium text-white truncate">
                    {user.display_name ?? '—'}
                    {user.is_admin && (
                      <span className="ml-2 badge-gold text-[9px] px-1.5 py-0.5">ADMIN</span>
                    )}
                    {user.is_banned && (
                      <span className="ml-2 text-[9px] px-1.5 py-0.5 rounded-full bg-red-500/10 border border-red-500/20 text-red-400">BANNED</span>
                    )}
                  </div>
                  <div className="text-xs text-[#5A5A5A] truncate">{user.email}</div>
                  <div className="text-xs text-[#3a3a3a] mt-0.5">Joined {formatDate(user.created_at)}</div>
                </div>

                {/* Wallet */}
                <div className="text-right shrink-0 hidden sm:block">
                  <div className="coin-display text-sm">
                    <Coins size={11} />
                    {formatCoins(wallet?.balance ?? 0)}
                  </div>
                  <div className="text-xs text-[#3a3a3a] mt-0.5">
                    Spent: {formatCoins(wallet?.lifetime_spent ?? 0)}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </AdminLayout>
  );
}
