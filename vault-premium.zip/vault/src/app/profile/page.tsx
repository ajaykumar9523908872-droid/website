import { redirect } from 'next/navigation';
import { currentUser } from '@clerk/nextjs/server';
import { supabaseAdmin, getUserByClerkId } from '@/lib/supabase';
import type { Metadata } from 'next';
import SiteLayout from '@/components/layout/SiteLayout';
import ContentCard from '@/components/media/ContentCard';
import { formatDate } from '@/lib/utils';
import { User, Calendar, Coins, Unlock } from 'lucide-react';

export const metadata: Metadata = { title: 'Profile' };

export default async function ProfilePage() {
  const clerkUser = await currentUser();
  if (!clerkUser) redirect('/login');

  const dbUser = await getUserByClerkId(clerkUser.id);
  if (!dbUser) redirect('/login');

  const [{ data: wallet }, { data: unlocks }] = await Promise.all([
    supabaseAdmin
      .from('wallet')
      .select('balance, lifetime_spent, lifetime_added')
      .eq('user_id', dbUser.id)
      .single(),
    supabaseAdmin
      .from('unlocked_content')
      .select('*, content(*)')
      .eq('user_id', dbUser.id)
      .order('unlocked_at', { ascending: false })
      .limit(24),
  ]);

  const unlockedContent = unlocks
    ?.filter((u) => u.content)
    .map((u) => ({
      ...(u.content as any),
      is_unlocked: true,
      unlocked_at: u.unlocked_at,
      thumbnail_url: u.content?.thumbnail_key
        ? `${process.env.NEXT_PUBLIC_APP_URL}/api/content/thumbnail/${u.content?.id}`
        : null,
    })) ?? [];

  return (
    <SiteLayout walletBalance={wallet?.balance ?? 0}>
      <div className="max-w-6xl mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-end gap-6 mb-10">
          {clerkUser.imageUrl ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img
              src={clerkUser.imageUrl}
              alt="Avatar"
              className="w-20 h-20 rounded-full border-2 border-gold/20 shrink-0"
            />
          ) : (
            <div className="w-20 h-20 rounded-full border-2 border-[#262626] bg-[#111111] flex items-center justify-center">
              <User size={28} className="text-[#5A5A5A]" />
            </div>
          )}

          <div>
            <h1 className="font-display text-4xl font-light text-white">
              {dbUser.display_name ?? clerkUser.firstName ?? 'My Account'}
            </h1>
            <p className="text-[#5A5A5A] text-sm mt-1">{dbUser.email}</p>
            <p className="text-[#3a3a3a] text-xs mt-0.5 flex items-center gap-1">
              <Calendar size={10} />
              Member since {formatDate(dbUser.created_at)}
            </p>
          </div>

          {/* Quick stats */}
          <div className="sm:ml-auto flex gap-6">
            <div className="text-center">
              <div className="font-display text-3xl text-gold font-light">
                {wallet?.balance ?? 0}
              </div>
              <div className="text-xs text-[#5A5A5A] uppercase tracking-wide mt-0.5">
                Coins
              </div>
            </div>
            <div className="text-center">
              <div className="font-display text-3xl text-white font-light">
                {unlockedContent.length}
              </div>
              <div className="text-xs text-[#5A5A5A] uppercase tracking-wide mt-0.5">
                Unlocked
              </div>
            </div>
            <div className="text-center">
              <div className="font-display text-3xl text-white font-light">
                {wallet?.lifetime_spent ?? 0}
              </div>
              <div className="text-xs text-[#5A5A5A] uppercase tracking-wide mt-0.5">
                Spent
              </div>
            </div>
          </div>
        </div>

        {/* Unlocked Content */}
        <div>
          <div className="flex items-center gap-2 mb-6">
            <Unlock size={16} className="text-gold" />
            <h2 className="font-display text-2xl text-white font-light">
              Unlocked Content
            </h2>
          </div>

          {unlockedContent.length === 0 ? (
            <div className="vault-card p-16 text-center">
              <Coins size={40} className="text-[#2a2a2a] mx-auto mb-4" />
              <p className="text-[#5A5A5A]">No unlocked content yet.</p>
              <p className="text-[#3a3a3a] text-sm mt-1">
                Browse the collection and unlock something exclusive.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
              {unlockedContent.map((item, i) => (
                <ContentCard
                  key={item.id}
                  content={item}
                  priority={i < 4}
                />
              ))}
            </div>
          )}
        </div>
      </div>
    </SiteLayout>
  );
}
