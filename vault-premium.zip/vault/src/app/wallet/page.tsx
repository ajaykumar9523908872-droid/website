import { redirect } from 'next/navigation';
import { currentUser } from '@clerk/nextjs/server';
import { supabaseAdmin, getUserByClerkId } from '@/lib/supabase';
import type { Metadata } from 'next';
import SiteLayout from '@/components/layout/SiteLayout';
import RechargePackages from '@/components/wallet/RechargePackages';
import TransactionHistory from '@/components/wallet/TransactionHistory';
import { RECHARGE_PACKAGES } from '@/lib/stripe';
import { formatCoins, formatDateTime, centToEuro } from '@/lib/utils';
import { Coins, TrendingUp, ShoppingBag, ArrowUpRight, ArrowDownLeft } from 'lucide-react';

export const metadata: Metadata = {
  title: 'Wallet',
  description: 'Manage your VAULT wallet. Recharge coins and view transaction history.',
};

export default async function WalletPage() {
  const clerkUser = await currentUser();
  if (!clerkUser) redirect('/login');

  const dbUser = await getUserByClerkId(clerkUser.id);
  if (!dbUser) redirect('/login');

  const [{ data: wallet }, { data: transactions }] = await Promise.all([
    supabaseAdmin
      .from('wallet')
      .select('*')
      .eq('user_id', dbUser.id)
      .single(),
    supabaseAdmin
      .from('wallet_transactions')
      .select('*')
      .eq('user_id', dbUser.id)
      .order('created_at', { ascending: false })
      .limit(50),
  ]);

  const balance = wallet?.balance ?? 0;
  const lifetimeSpent = wallet?.lifetime_spent ?? 0;
  const lifetimeAdded = wallet?.lifetime_added ?? 0;

  return (
    <SiteLayout walletBalance={balance}>
      <div className="max-w-4xl mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8">
          <span className="badge-gold block mb-3">My Wallet</span>
          <h1 className="font-display text-4xl font-light text-white">
            Wallet & Balance
          </h1>
        </div>

        {/* Balance card */}
        <div className="relative rounded-3xl overflow-hidden bg-gradient-to-br from-[#1a1500] to-[#0d0d0d] border border-gold/20 p-8 mb-8">
          <div className="absolute inset-0 bg-hero-radial opacity-30" />
          <div className="relative z-10">
            <div className="flex flex-col sm:flex-row sm:items-end sm:justify-between gap-6">
              <div>
                <div className="text-[#5A5A5A] text-sm uppercase tracking-widest mb-3">
                  Available Balance
                </div>
                <div className="flex items-end gap-3">
                  <Coins size={32} className="text-gold mb-1" />
                  <span className="font-display text-6xl sm:text-7xl font-light text-gold">
                    {formatCoins(balance)}
                  </span>
                  <span className="text-[#A0A0A0] mb-2 text-lg">coins</span>
                </div>
                <div className="text-[#5A5A5A] text-sm mt-2">
                  ≈ €{(balance / 100).toFixed(2)} value
                </div>
              </div>

              {/* Stats */}
              <div className="flex gap-8 sm:gap-6">
                <div className="text-center">
                  <div className="text-[#5A5A5A] text-xs uppercase tracking-wide mb-1">
                    Total Added
                  </div>
                  <div className="font-mono text-white text-lg">{formatCoins(lifetimeAdded)}</div>
                </div>
                <div className="text-center">
                  <div className="text-[#5A5A5A] text-xs uppercase tracking-wide mb-1">
                    Total Spent
                  </div>
                  <div className="font-mono text-white text-lg">{formatCoins(lifetimeSpent)}</div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Recharge packages */}
        <section className="mb-10">
          <h2 className="font-display text-2xl text-white mb-6">Recharge Coins</h2>
          <RechargePackages packages={RECHARGE_PACKAGES} />
        </section>

        {/* Transaction history */}
        <section>
          <h2 className="font-display text-2xl text-white mb-6">Transaction History</h2>
          <TransactionHistory transactions={transactions ?? []} />
        </section>
      </div>
    </SiteLayout>
  );
}
