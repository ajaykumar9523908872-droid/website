import { NextRequest, NextResponse } from 'next/server';
import { constructWebhookEvent } from '@/lib/stripe';
import { supabaseAdmin } from '@/lib/supabase';
import type Stripe from 'stripe';

// Stripe webhooks need raw body
export const config = { api: { bodyParser: false } };

export async function POST(request: NextRequest) {
  const signature = request.headers.get('stripe-signature');
  if (!signature) {
    return NextResponse.json({ error: 'No signature' }, { status: 400 });
  }

  const body = await request.arrayBuffer();
  const payload = Buffer.from(body);

  let event: Stripe.Event;
  try {
    event = constructWebhookEvent(payload, signature);
  } catch (err) {
    console.error('Webhook signature verification failed:', err);
    return NextResponse.json({ error: 'Invalid signature' }, { status: 400 });
  }

  try {
    switch (event.type) {
      case 'checkout.session.completed': {
        const session = event.data.object as Stripe.Checkout.Session;
        await handleCheckoutCompleted(session);
        break;
      }
      case 'payment_intent.payment_failed': {
        const pi = event.data.object as Stripe.PaymentIntent;
        await handlePaymentFailed(pi);
        break;
      }
      default:
        // Ignore unhandled events
        break;
    }

    return NextResponse.json({ received: true });
  } catch (error) {
    console.error('Webhook handler error:', error);
    return NextResponse.json({ error: 'Handler failed' }, { status: 500 });
  }
}

async function handleCheckoutCompleted(session: Stripe.Checkout.Session) {
  const userId = session.metadata?.user_id;
  const coinsStr = session.metadata?.coins;

  if (!userId || !coinsStr) {
    console.error('Missing metadata in session:', session.id);
    return;
  }

  const coins = parseInt(coinsStr, 10);
  const amountCents = session.amount_total ?? 0;
  const paymentIntentId = session.payment_intent as string;

  // Idempotency: check if payment already processed
  const { data: existing } = await supabaseAdmin
    .from('payments')
    .select('id, status')
    .eq('stripe_payment_intent', paymentIntentId)
    .single();

  if (existing?.status === 'succeeded') {
    console.log('Payment already processed:', paymentIntentId);
    return;
  }

  // Insert or update payment record
  const { data: payment, error: paymentError } = await supabaseAdmin
    .from('payments')
    .upsert({
      user_id: userId,
      stripe_payment_intent: paymentIntentId,
      stripe_session_id: session.id,
      amount_eur_cents: amountCents,
      coins_purchased: coins,
      status: 'succeeded',
      metadata: { session_id: session.id },
    }, { onConflict: 'stripe_payment_intent' })
    .select()
    .single();

  if (paymentError) {
    console.error('Failed to record payment:', paymentError);
    throw paymentError;
  }

  // Add coins to wallet
  const { error: addError } = await supabaseAdmin.rpc('add_coins', {
    p_user_id: userId,
    p_amount: coins,
    p_payment_id: payment.id,
    p_description: `Recharged ${coins} coins (€${(amountCents / 100).toFixed(2)})`,
  });

  if (addError) {
    console.error('Failed to add coins:', addError);
    throw addError;
  }

  // Analytics
  await supabaseAdmin.from('analytics').insert({
    event: 'recharge_complete',
    user_id: userId,
    metadata: { coins, amount_cents: amountCents, payment_id: payment.id },
  });

  console.log(`✅ Added ${coins} coins to user ${userId}`);
}

async function handlePaymentFailed(pi: Stripe.PaymentIntent) {
  const userId = pi.metadata?.user_id;
  if (!userId) return;

  await supabaseAdmin
    .from('payments')
    .update({ status: 'failed' })
    .eq('stripe_payment_intent', pi.id);
}
