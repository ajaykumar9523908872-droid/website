import { NextRequest, NextResponse } from 'next/server';
import { auth } from '@clerk/nextjs/server';
import { supabaseAdmin } from '@/lib/supabase';
import { getSignedUploadUrl, generateContentKey } from '@/lib/r2';
import { isAdmin } from '@/lib/utils';

export async function POST(request: NextRequest) {
  const { userId: clerkId } = auth();
  if (!clerkId || !isAdmin(clerkId)) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 403 });
  }

  try {
    const body = await request.json();
    const {
      title, description, coinPrice, type, isFeatured,
      isPremium, tags, status, fileName, fileType, fileSize,
    } = body;

    if (!title || !type || !fileName || !fileType) {
      return NextResponse.json({ error: 'Missing required fields' }, { status: 400 });
    }

    // Create content record first (gets us an ID)
    const { data: content, error } = await supabaseAdmin
      .from('content')
      .insert({
        title,
        description: description || null,
        coin_price: coinPrice,
        type,
        is_featured: isFeatured,
        is_premium: isPremium,
        tags: tags || [],
        status,
        file_size_bytes: fileSize,
      })
      .select()
      .single();

    if (error || !content) {
      throw error ?? new Error('Failed to create content record');
    }

    // Generate storage key and signed upload URL
    const storageKey = generateContentKey(content.id, type, 'original');
    const uploadUrl = await getSignedUploadUrl(storageKey, fileType, 600); // 10 min

    // Update record with storage key
    await supabaseAdmin
      .from('content')
      .update({ storage_key: storageKey })
      .eq('id', content.id);

    return NextResponse.json({ contentId: content.id, uploadUrl });
  } catch (err) {
    console.error('Admin upload error:', err);
    return NextResponse.json({ error: 'Failed to initialize upload' }, { status: 500 });
  }
}

export async function GET(request: NextRequest) {
  const { userId: clerkId } = auth();
  if (!clerkId || !isAdmin(clerkId)) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 403 });
  }

  const url = new URL(request.url);
  const page = parseInt(url.searchParams.get('page') ?? '1');
  const pageSize = 20;
  const offset = (page - 1) * pageSize;

  const { data, error, count } = await supabaseAdmin
    .from('content')
    .select('*', { count: 'exact' })
    .order('created_at', { ascending: false })
    .range(offset, offset + pageSize - 1);

  if (error) return NextResponse.json({ error: 'Fetch failed' }, { status: 500 });

  return NextResponse.json({ content: data, total: count, page, pageSize });
}
