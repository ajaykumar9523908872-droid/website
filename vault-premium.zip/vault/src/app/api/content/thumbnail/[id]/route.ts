import { NextRequest, NextResponse } from 'next/server';
import { supabaseAdmin } from '@/lib/supabase';
import { getSignedReadUrl } from '@/lib/r2';

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  const { data: content } = await supabaseAdmin
    .from('content')
    .select('thumbnail_key, status')
    .eq('id', params.id)
    .single();

  if (!content || content.status !== 'published') {
    return new NextResponse(null, { status: 404 });
  }

  if (!content.thumbnail_key) {
    return new NextResponse(null, { status: 404 });
  }

  try {
    // Redirect to a short-lived signed URL
    const signedUrl = await getSignedReadUrl(content.thumbnail_key, 3600);
    return NextResponse.redirect(signedUrl, {
      headers: {
        'Cache-Control': 'public, max-age=3600',
      },
    });
  } catch {
    return new NextResponse(null, { status: 500 });
  }
}
