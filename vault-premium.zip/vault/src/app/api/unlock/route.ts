import { NextRequest, NextResponse } from 'next/server';
import { auth } from '@clerk/nextjs/server';
import { supabaseAdmin, getUserByClerkId } from '@/lib/supabase';
import { checkRateLimit } from '@/lib/utils';

export async function POST(request: NextRequest) {
  try {
    // Auth check
    const { userId: clerkId } = auth();
    if (!clerkId) {
      return NextResponse.json({ error: 'Unauthorized', success: false }, { status: 401 });
    }

    // Rate limit: 10 unlocks per minute
    const { allowed } = checkRateLimit(`unlock:${clerkId}`, 10, 60_000);
    if (!allowed) {
      return NextResponse.json({ error: 'Too many requests', success: false }, { status: 429 });
    }

    const body = await request.json();
    const { contentId } = body;

    if (!contentId || typeof contentId !== 'string') {
      return NextResponse.json({ error: 'Invalid content ID', success: false }, { status: 400 });
    }

    // Get user record
    const dbUser = await getUserByClerkId(clerkId);
    if (!dbUser) {
      return NextResponse.json({ error: 'User not found', success: false }, { status: 404 });
    }

    if (dbUser.is_banned) {
      return NextResponse.json({ error: 'Account suspended', success: false }, { status: 403 });
    }

    // Verify content exists and is published
    const { data: content, error: contentError } = await supabaseAdmin
      .from('content')
      .select('id, coin_price, title, status')
      .eq('id', contentId)
      .eq('status', 'published')
      .single();

    if (contentError || !content) {
      return NextResponse.json({ error: 'Content not found', success: false }, { status: 404 });
    }

    // Check if already unlocked
    const { data: existingUnlock } = await supabaseAdmin
      .from('unlocked_content')
      .select('id')
      .eq('user_id', dbUser.id)
      .eq('content_id', contentId)
      .single();

    if (existingUnlock) {
      return NextResponse.json({ success: true, alreadyUnlocked: true }, { status: 200 });
    }

    // Attempt to deduct coins atomically via DB function
    const { data: result, error: deductError } = await supabaseAdmin.rpc('deduct_coins', {
      p_user_id: dbUser.id,
      p_amount: content.coin_price,
      p_content_id: contentId,
      p_description: `Unlocked: ${content.title}`,
    });

    if (deductError || !result?.[0]) {
      console.error('Deduct error:', deductError);
      return NextResponse.json({ error: 'Transaction failed', success: false }, { status: 500 });
    }

    const txResult = result[0];

    if (!txResult.success) {
      if (txResult.error === 'Insufficient balance') {
        return NextResponse.json({
          success: false,
          error: 'Insufficient balance',
          requiresRecharge: true,
          currentBalance: 0,
        }, { status: 402 });
      }
      return NextResponse.json({ error: txResult.error, success: false }, { status: 400 });
    }

    // Log analytics
    await supabaseAdmin.from('analytics').insert({
      event: 'content_unlock',
      content_id: contentId,
      user_id: dbUser.id,
      metadata: { coins_spent: content.coin_price },
    });

    return NextResponse.json({
      success: true,
      newBalance: txResult.new_balance,
    });
  } catch (error) {
    console.error('Unlock error:', error);
    return NextResponse.json({ error: 'Internal server error', success: false }, { status: 500 });
  }
}
