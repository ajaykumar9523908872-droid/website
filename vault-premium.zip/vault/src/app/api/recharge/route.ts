import { NextRequest, NextResponse } from 'next/server';
import { auth } from '@clerk/nextjs/server';
import { getUserByClerkId } from '@/lib/supabase';
import { createRechargeSession, RECHARGE_PACKAGES } from '@/lib/stripe';

export async function POST(request: NextRequest) {
  try {
    const { userId: clerkId } = auth();
    if (!clerkId) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const dbUser = await getUserByClerkId(clerkId);
    if (!dbUser) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 });
    }

    const body = await request.json();
    const { packageIndex, customCoins } = body;

    let coins: number;
    let priceCents: number;

    if (packageIndex === -1 && customCoins) {
      // Custom amount: minimum 100 coins
      if (customCoins < 100 || customCoins > 100_000) {
        return NextResponse.json({ error: 'Invalid coin amount' }, { status: 400 });
      }
      coins = Math.floor(customCoins);
      priceCents = Math.ceil(coins); // 100 coins = €1 = 100 cents
    } else {
      const pkg = RECHARGE_PACKAGES[packageIndex];
      if (!pkg) {
        return NextResponse.json({ error: 'Invalid package' }, { status: 400 });
      }
      coins = pkg.coins;
      priceCents = pkg.price_cents;
    }

    const baseUrl = process.env.NEXT_PUBLIC_APP_URL!;

    const session = await createRechargeSession(
      dbUser.id,
      dbUser.email,
      coins,
      priceCents,
      `${baseUrl}/wallet?recharged=true&coins=${coins}`,
      `${baseUrl}/wallet?cancelled=true`
    );

    return NextResponse.json({ checkoutUrl: session.url });
  } catch (error) {
    console.error('Recharge error:', error);
    return NextResponse.json({ error: 'Failed to create checkout' }, { status: 500 });
  }
}
