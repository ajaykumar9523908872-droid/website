import { NextRequest, NextResponse } from 'next/server';
import { Webhook } from 'svix';
import { supabaseAdmin } from '@/lib/supabase';

export async function POST(request: NextRequest) {
  const svixId = request.headers.get('svix-id');
  const svixTimestamp = request.headers.get('svix-timestamp');
  const svixSignature = request.headers.get('svix-signature');

  if (!svixId || !svixTimestamp || !svixSignature) {
    return NextResponse.json({ error: 'Missing Svix headers' }, { status: 400 });
  }

  const body = await request.text();
  const webhookSecret = process.env.CLERK_WEBHOOK_SECRET;

  if (!webhookSecret) {
    return NextResponse.json({ error: 'Webhook secret not configured' }, { status: 500 });
  }

  let event: any;
  try {
    const wh = new Webhook(webhookSecret);
    event = wh.verify(body, {
      'svix-id': svixId,
      'svix-timestamp': svixTimestamp,
      'svix-signature': svixSignature,
    });
  } catch {
    return NextResponse.json({ error: 'Invalid signature' }, { status: 400 });
  }

  const { type, data } = event;

  switch (type) {
    case 'user.created': {
      const email = data.email_addresses?.[0]?.email_address;
      if (!email) break;

      await supabaseAdmin.from('users').upsert({
        clerk_id: data.id,
        email,
        display_name: [data.first_name, data.last_name].filter(Boolean).join(' ') || null,
        avatar_url: data.image_url || null,
        is_admin: data.id === process.env.ADMIN_USER_ID,
      }, { onConflict: 'clerk_id' });
      break;
    }

    case 'user.updated': {
      const email = data.email_addresses?.[0]?.email_address;
      await supabaseAdmin
        .from('users')
        .update({
          email: email,
          display_name: [data.first_name, data.last_name].filter(Boolean).join(' ') || null,
          avatar_url: data.image_url || null,
          updated_at: new Date().toISOString(),
        })
        .eq('clerk_id', data.id);
      break;
    }

    case 'user.deleted': {
      await supabaseAdmin.from('users').delete().eq('clerk_id', data.id);
      break;
    }
  }

  return NextResponse.json({ received: true });
}
