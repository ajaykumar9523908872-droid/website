import type { Metadata, Viewport } from 'next';
import { ClerkProvider } from '@clerk/nextjs';
import { Toaster } from 'sonner';
import '@/styles/globals.css';

export const metadata: Metadata = {
  title: {
    default: 'VAULT — Premium Content',
    template: '%s | VAULT',
  },
  description: 'Premium content, unlocked. Browse exclusive images and videos. Recharge your wallet and unlock content instantly.',
  keywords: ['premium content', 'exclusive media', 'vault'],
  robots: { index: true, follow: true },
  openGraph: {
    type: 'website',
    siteName: 'VAULT',
    title: 'VAULT — Premium Content',
    description: 'Premium content, unlocked.',
  },
};

export const viewport: Viewport = {
  themeColor: '#080808',
  width: 'device-width',
  initialScale: 1,
  maximumScale: 5,
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <ClerkProvider>
      <html lang="en" className="dark">
        <head>
          <link rel="preconnect" href="https://fonts.googleapis.com" />
          <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
          <link
            href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,300;0,400;0,500;0,600;1,300;1,400&family=Outfit:wght@300;400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap"
            rel="stylesheet"
          />
        </head>
        <body className="bg-background text-white font-body antialiased">
          {children}
          <Toaster
            position="bottom-right"
            toastOptions={{
              style: {
                background: '#111111',
                border: '1px solid #262626',
                color: '#ffffff',
                fontFamily: 'var(--font-outfit)',
              },
            }}
          />
        </body>
      </html>
    </ClerkProvider>
  );
}
