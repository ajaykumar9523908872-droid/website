import { Suspense } from 'react';
import type { Metadata } from 'next';
import SiteLayout from '@/components/layout/SiteLayout';
import ExploreGrid from '@/components/media/ExploreGrid';
import ExploreFilters from '@/components/media/ExploreFilters';
import { createServerSupabase } from '@/lib/supabase';
import { currentUser } from '@clerk/nextjs/server';
import { getUserByClerkId } from '@/lib/supabase';

export const metadata: Metadata = {
  title: 'Explore',
  description: 'Browse exclusive premium content. Images and videos available to unlock.',
};

interface ExplorePageProps {
  searchParams: {
    type?: string;
    sort?: string;
    premium?: string;
    page?: string;
  };
}

export default async function ExplorePage({ searchParams }: ExplorePageProps) {
  const clerkUser = await currentUser();

  let dbUser = null;
  let unlockedIds: string[] = [];

  if (clerkUser) {
    dbUser = await getUserByClerkId(clerkUser.id);
    if (dbUser) {
      const supabase = createServerSupabase();
      const { data: unlocked } = await supabase
        .from('unlocked_content')
        .select('content_id')
        .eq('user_id', dbUser.id);
      unlockedIds = unlocked?.map((u) => u.content_id) ?? [];
    }
  }

  const type = (searchParams.type ?? 'all') as 'all' | 'image' | 'video';
  const sort = (searchParams.sort ?? 'newest') as 'newest' | 'popular' | 'price_asc' | 'price_desc';
  const premium = searchParams.premium === 'true';

  return (
    <SiteLayout>
      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8">
          <span className="badge-gold block mb-3">Browse</span>
          <h1 className="font-display text-4xl sm:text-5xl font-light text-white">
            Explore Collection
          </h1>
          <p className="text-[#A0A0A0] mt-2">
            Discover exclusive premium content. Tap to unlock instantly.
          </p>
        </div>

        {/* Filters */}
        <ExploreFilters
          currentType={type}
          currentSort={sort}
          currentPremium={premium}
        />

        {/* Grid */}
        <Suspense fallback={<ExploreGridSkeleton />}>
          <ExploreGrid
            type={type}
            sort={sort}
            premium={premium}
            unlockedIds={unlockedIds}
          />
        </Suspense>
      </div>
    </SiteLayout>
  );
}

function ExploreGridSkeleton() {
  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 mt-6">
      {Array.from({ length: 12 }).map((_, i) => (
        <div key={i} className="space-y-3">
          <div className="aspect-[3/4] rounded-2xl skeleton" />
          <div className="h-3 rounded skeleton w-3/4" />
          <div className="h-3 rounded skeleton w-1/2" />
        </div>
      ))}
    </div>
  );
}
