'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useUser, UserButton, SignInButton } from '@clerk/nextjs';
import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Grid, Wallet, User, Menu, X, Coins, Crown } from 'lucide-react';
import { cn } from '@/lib/utils';

interface SiteLayoutProps {
  children: React.ReactNode;
  walletBalance?: number;
}

export default function SiteLayout({ children, walletBalance }: SiteLayoutProps) {
  const { isSignedIn, user } = useUser();
  const pathname = usePathname();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const navLinks = [
    { href: '/explore', label: 'Explore', icon: Grid },
    { href: '/wallet', label: 'Wallet', icon: Wallet },
    { href: '/profile', label: 'Profile', icon: User },
  ];

  return (
    <div className="min-h-screen flex flex-col">
      {/* ─── Navbar ─── */}
      <nav
        className={cn(
          'fixed top-0 left-0 right-0 z-50 transition-all duration-300',
          scrolled
            ? 'bg-[#080808]/95 backdrop-blur-xl border-b border-[#1a1a1a]'
            : 'bg-transparent'
        )}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="flex items-center justify-between h-16">
            {/* Logo */}
            <Link href="/" className="flex items-center gap-2 group">
              <div className="relative">
                <Crown
                  size={20}
                  className="text-gold transition-all duration-300 group-hover:drop-shadow-[0_0_8px_rgba(212,175,55,0.8)]"
                />
              </div>
              <span className="font-display text-xl font-semibold tracking-[0.2em] text-white">
                VAULT
              </span>
            </Link>

            {/* Desktop Nav */}
            <div className="hidden md:flex items-center gap-8">
              {navLinks.map(({ href, label }) => (
                <Link
                  key={href}
                  href={href}
                  className={cn(
                    'text-sm font-medium transition-colors duration-200 tracking-wide',
                    pathname === href
                      ? 'text-gold'
                      : 'text-[#A0A0A0] hover:text-white'
                  )}
                >
                  {label}
                </Link>
              ))}
            </div>

            {/* Right side */}
            <div className="flex items-center gap-3">
              {isSignedIn ? (
                <>
                  {/* Wallet balance */}
                  <Link
                    href="/wallet"
                    className="hidden sm:flex items-center gap-1.5 bg-[#111111] border border-[#262626] rounded-full px-3 py-1.5 hover:border-gold/40 transition-colors duration-200"
                  >
                    <Coins size={13} className="text-gold" />
                    <span className="text-xs font-mono text-gold font-medium">
                      {walletBalance ?? '—'}
                    </span>
                  </Link>

                  <UserButton
                    appearance={{
                      elements: {
                        avatarBox: 'w-8 h-8 ring-1 ring-[#262626] hover:ring-gold/50 transition-all',
                      },
                    }}
                  />
                </>
              ) : (
                <SignInButton mode="modal">
                  <button className="btn-gold text-black text-sm font-semibold px-4 py-2 rounded-full">
                    Sign In
                  </button>
                </SignInButton>
              )}

              {/* Mobile menu button */}
              <button
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="md:hidden p-2 text-[#A0A0A0] hover:text-white transition-colors"
              >
                {mobileMenuOpen ? <X size={20} /> : <Menu size={20} />}
              </button>
            </div>
          </div>
        </div>
      </nav>

      {/* ─── Mobile Menu ─── */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.2 }}
            className="fixed inset-x-0 top-16 z-40 bg-[#0d0d0d]/98 backdrop-blur-xl border-b border-[#1a1a1a] md:hidden"
          >
            <div className="px-4 py-6 space-y-4">
              {navLinks.map(({ href, label, icon: Icon }) => (
                <Link
                  key={href}
                  href={href}
                  onClick={() => setMobileMenuOpen(false)}
                  className={cn(
                    'flex items-center gap-3 text-base font-medium py-2',
                    pathname === href ? 'text-gold' : 'text-[#A0A0A0]'
                  )}
                >
                  <Icon size={18} />
                  {label}
                </Link>
              ))}
              {isSignedIn && walletBalance !== undefined && (
                <div className="flex items-center gap-2 pt-2 border-t border-[#1a1a1a]">
                  <Coins size={14} className="text-gold" />
                  <span className="text-sm font-mono text-gold">{walletBalance} coins</span>
                </div>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ─── Main content ─── */}
      <main className="flex-1 pt-16 page-enter">
        {children}
      </main>

      {/* ─── Footer ─── */}
      <footer className="border-t border-[#1a1a1a] py-8 px-4">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <Crown size={14} className="text-gold" />
            <span className="font-display text-sm tracking-widest text-[#5A5A5A]">VAULT</span>
          </div>
          <p className="text-xs text-[#5A5A5A]">
            © {new Date().getFullYear()} VAULT. Premium content platform.
          </p>
          <div className="flex gap-4 text-xs text-[#5A5A5A]">
            <Link href="/terms" className="hover:text-white transition-colors">Terms</Link>
            <Link href="/privacy" className="hover:text-white transition-colors">Privacy</Link>
          </div>
        </div>
      </footer>
    </div>
  );
}
