'use client';

import { useState } from 'react';
import { motion } from 'framer-motion';
import { Coins, Loader2, Zap, Star } from 'lucide-react';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';
import type { RechargePackage } from '@/types';

interface RechargePackagesProps {
  packages: RechargePackage[];
}

export default function RechargePackages({ packages }: RechargePackagesProps) {
  const [selectedIndex, setSelectedIndex] = useState(1); // Default "Popular"
  const [loading, setLoading] = useState(false);
  const [customCoins, setCustomCoins] = useState('');
  const [isCustom, setIsCustom] = useState(false);

  const handleRecharge = async () => {
    setLoading(true);
    try {
      const body = isCustom
        ? { packageIndex: -1, customCoins: parseInt(customCoins) }
        : { packageIndex: selectedIndex };

      const res = await fetch('/api/recharge', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });

      const data = await res.json();
      if (data.checkoutUrl) {
        window.location.href = data.checkoutUrl;
      } else {
        toast.error(data.error ?? 'Failed to start checkout');
      }
    } catch {
      toast.error('Network error. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Package grid */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {packages.map((pkg, i) => (
          <motion.button
            key={i}
            onClick={() => { setSelectedIndex(i); setIsCustom(false); }}
            whileTap={{ scale: 0.98 }}
            className={cn(
              'relative p-6 rounded-2xl border text-left transition-all duration-300',
              !isCustom && selectedIndex === i
                ? 'border-gold bg-gold-muted shadow-gold'
                : 'border-[#262626] bg-[#111111] hover:border-[#3a3a3a]'
            )}
          >
            {pkg.badge && (
              <div className="absolute -top-2.5 left-4">
                <span className="badge-gold text-[10px] px-2 py-0.5">
                  {pkg.badge}
                </span>
              </div>
            )}

            <div className="flex items-center gap-2 mb-4">
              <Coins size={16} className={!isCustom && selectedIndex === i ? 'text-gold' : 'text-[#5A5A5A]'} />
              <span className="text-xs text-[#5A5A5A] uppercase tracking-wide">
                {pkg.label}
              </span>
            </div>

            <div className="font-display text-4xl font-light text-white mb-1">
              {pkg.coins.toLocaleString()}
            </div>
            <div className="text-[#5A5A5A] text-sm">coins</div>

            <div className={cn(
              'mt-4 pt-4 border-t text-sm font-semibold',
              !isCustom && selectedIndex === i
                ? 'border-gold/20 text-gold'
                : 'border-[#1a1a1a] text-white'
            )}>
              €{(pkg.price_cents / 100).toFixed(2)}
            </div>

            {pkg.coins > 100 && (
              <div className="text-xs text-[#5A5A5A] mt-1">
                €{((pkg.price_cents / pkg.coins) * 100).toFixed(3)}/coin
              </div>
            )}
          </motion.button>
        ))}
      </div>

      {/* Custom amount */}
      <div className={cn(
        'rounded-2xl border p-5 transition-all duration-300',
        isCustom ? 'border-gold bg-gold-muted' : 'border-[#262626] bg-[#111111]'
      )}>
        <button
          onClick={() => setIsCustom(true)}
          className="text-sm text-[#A0A0A0] hover:text-white transition-colors mb-3 flex items-center gap-2"
        >
          <Zap size={14} className="text-gold" />
          Custom amount
        </button>
        {isCustom && (
          <div className="flex gap-3">
            <div className="relative flex-1">
              <Coins size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-gold" />
              <input
                type="number"
                value={customCoins}
                onChange={(e) => setCustomCoins(e.target.value)}
                placeholder="Enter coins (min 100)"
                min={100}
                className="vault-input pl-9"
                autoFocus
              />
            </div>
            {customCoins && parseInt(customCoins) >= 100 && (
              <div className="flex items-center text-sm text-[#A0A0A0] shrink-0">
                = €{(parseInt(customCoins) / 100).toFixed(2)}
              </div>
            )}
          </div>
        )}
      </div>

      {/* Recharge button */}
      <motion.button
        onClick={handleRecharge}
        disabled={loading || (isCustom && (!customCoins || parseInt(customCoins) < 100))}
        whileTap={{ scale: 0.98 }}
        className="btn-gold w-full py-4 rounded-2xl text-black font-semibold text-base flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:transform-none"
      >
        {loading ? (
          <>
            <Loader2 size={18} className="animate-spin" />
            Processing…
          </>
        ) : (
          <>
            <Coins size={18} />
            Recharge Now
            <span className="text-black/70 text-sm ml-1">
              · {isCustom ? customCoins || '—' : packages[selectedIndex]?.coins.toLocaleString()} coins
            </span>
          </>
        )}
      </motion.button>

      <p className="text-xs text-[#3a3a3a] text-center">
        Secure payment via Stripe. Cards, Apple Pay, Google Pay & PayPal accepted.
      </p>
    </div>
  );
}
