'use client';

import { ArrowDownLeft, ArrowUpRight, Gift, RotateCcw } from 'lucide-react';
import { formatDateTime, formatCoins } from '@/lib/utils';
import { cn } from '@/lib/utils';
import type { WalletTransaction } from '@/types';

interface TransactionHistoryProps {
  transactions: WalletTransaction[];
}

const typeConfig = {
  recharge: {
    icon: ArrowDownLeft,
    label: 'Recharge',
    color: 'text-emerald-400',
    bg: 'bg-emerald-500/10',
    prefix: '+',
  },
  unlock: {
    icon: ArrowUpRight,
    label: 'Content Unlock',
    color: 'text-[#A0A0A0]',
    bg: 'bg-white/5',
    prefix: '',
  },
  refund: {
    icon: RotateCcw,
    label: 'Refund',
    color: 'text-blue-400',
    bg: 'bg-blue-500/10',
    prefix: '+',
  },
  bonus: {
    icon: Gift,
    label: 'Bonus',
    color: 'text-gold',
    bg: 'bg-gold/10',
    prefix: '+',
  },
};

export default function TransactionHistory({ transactions }: TransactionHistoryProps) {
  if (transactions.length === 0) {
    return (
      <div className="vault-card p-12 text-center">
        <p className="text-[#5A5A5A]">No transactions yet.</p>
        <p className="text-[#3a3a3a] text-sm mt-1">Recharge your wallet to get started.</p>
      </div>
    );
  }

  return (
    <div className="vault-card divide-y divide-[#1a1a1a]">
      {transactions.map((tx) => {
        const config = typeConfig[tx.type] ?? typeConfig.unlock;
        const Icon = config.icon;
        const isCredit = tx.amount > 0;

        return (
          <div key={tx.id} className="flex items-center gap-4 p-4 hover:bg-white/[0.02] transition-colors">
            <div className={cn('w-9 h-9 rounded-xl flex items-center justify-center shrink-0', config.bg)}>
              <Icon size={15} className={config.color} />
            </div>

            <div className="flex-1 min-w-0">
              <div className="text-sm font-medium text-white">{config.label}</div>
              {tx.description && (
                <div className="text-xs text-[#5A5A5A] truncate mt-0.5">{tx.description}</div>
              )}
              <div className="text-xs text-[#3a3a3a] mt-0.5">{formatDateTime(tx.created_at)}</div>
            </div>

            <div className="text-right shrink-0">
              <div className={cn(
                'font-mono text-sm font-medium',
                isCredit ? 'text-emerald-400' : 'text-[#A0A0A0]'
              )}>
                {isCredit ? '+' : ''}{formatCoins(tx.amount)} coins
              </div>
              <div className="text-xs text-[#3a3a3a] font-mono mt-0.5">
                Balance: {formatCoins(tx.balance_after)}
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
}
