'use client';

import { useRouter, usePathname, useSearchParams } from 'next/navigation';
import { useCallback } from 'react';
import { SlidersHorizontal } from 'lucide-react';
import { cn } from '@/lib/utils';

interface ExploreFiltersProps {
  currentType: string;
  currentSort: string;
  currentPremium: boolean;
}

export default function ExploreFilters({
  currentType,
  currentSort,
  currentPremium,
}: ExploreFiltersProps) {
  const router = useRouter();
  const pathname = usePathname();
  const searchParams = useSearchParams();

  const updateParam = useCallback(
    (key: string, value: string) => {
      const params = new URLSearchParams(searchParams.toString());
      params.set(key, value);
      router.push(`${pathname}?${params.toString()}`);
    },
    [pathname, router, searchParams]
  );

  const togglePremium = useCallback(() => {
    const params = new URLSearchParams(searchParams.toString());
    if (currentPremium) {
      params.delete('premium');
    } else {
      params.set('premium', 'true');
    }
    router.push(`${pathname}?${params.toString()}`);
  }, [currentPremium, pathname, router, searchParams]);

  return (
    <div className="flex flex-wrap items-center gap-3 mb-6">
      {/* Type filters */}
      <div className="flex bg-[#111111] border border-[#262626] rounded-full p-1 gap-1">
        {[
          { value: 'all', label: 'All' },
          { value: 'image', label: 'Images' },
          { value: 'video', label: 'Videos' },
        ].map(({ value, label }) => (
          <button
            key={value}
            onClick={() => updateParam('type', value)}
            className={cn(
              'px-4 py-1.5 rounded-full text-sm font-medium transition-all duration-200',
              currentType === value
                ? 'bg-gold text-black'
                : 'text-[#A0A0A0] hover:text-white'
            )}
          >
            {label}
          </button>
        ))}
      </div>

      {/* Sort */}
      <div className="flex bg-[#111111] border border-[#262626] rounded-full p-1 gap-1">
        {[
          { value: 'newest', label: 'New' },
          { value: 'popular', label: 'Popular' },
          { value: 'price_asc', label: 'Cheapest' },
          { value: 'price_desc', label: 'Premium' },
        ].map(({ value, label }) => (
          <button
            key={value}
            onClick={() => updateParam('sort', value)}
            className={cn(
              'px-4 py-1.5 rounded-full text-sm font-medium transition-all duration-200',
              currentSort === value
                ? 'bg-white/10 text-white'
                : 'text-[#A0A0A0] hover:text-white'
            )}
          >
            {label}
          </button>
        ))}
      </div>

      {/* Premium toggle */}
      <button
        onClick={togglePremium}
        className={cn(
          'flex items-center gap-2 px-4 py-2 rounded-full border text-sm font-medium transition-all duration-200',
          currentPremium
            ? 'border-gold bg-gold-muted text-gold'
            : 'border-[#262626] bg-[#111111] text-[#A0A0A0] hover:border-gold/30 hover:text-white'
        )}
      >
        <SlidersHorizontal size={14} />
        Premium Only
      </button>
    </div>
  );
}
