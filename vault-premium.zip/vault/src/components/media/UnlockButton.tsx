'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { motion, AnimatePresence } from 'framer-motion';
import { Lock, Unlock, Coins, Loader2, AlertCircle } from 'lucide-react';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';

interface UnlockButtonProps {
  contentId: string;
  coinPrice: number;
  walletBalance: number;
  isSignedIn: boolean;
  contentTitle: string;
}

type State = 'idle' | 'loading' | 'success' | 'insufficient';

export default function UnlockButton({
  contentId,
  coinPrice,
  walletBalance,
  isSignedIn,
  contentTitle,
}: UnlockButtonProps) {
  const [state, setState] = useState<State>('idle');
  const [showRechargeModal, setShowRechargeModal] = useState(false);
  const router = useRouter();

  const hasEnoughBalance = walletBalance >= coinPrice;

  const handleUnlock = async () => {
    if (!isSignedIn) {
      router.push('/login');
      return;
    }

    if (!hasEnoughBalance) {
      setShowRechargeModal(true);
      return;
    }

    setState('loading');

    try {
      const res = await fetch('/api/unlock', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ contentId }),
      });

      const data = await res.json();

      if (data.success) {
        setState('success');
        toast.success(`"${contentTitle}" unlocked!`, {
          description: `${coinPrice} coins deducted. Enjoy!`,
        });
        setTimeout(() => router.refresh(), 800);
      } else if (data.requiresRecharge) {
        setState('idle');
        setShowRechargeModal(true);
      } else {
        setState('idle');
        toast.error(data.error ?? 'Failed to unlock. Please try again.');
      }
    } catch {
      setState('idle');
      toast.error('Network error. Please try again.');
    }
  };

  return (
    <>
      <motion.button
        onClick={handleUnlock}
        disabled={state === 'loading' || state === 'success'}
        whileTap={{ scale: 0.97 }}
        className={cn(
          'w-full flex items-center justify-center gap-2 py-4 rounded-2xl font-semibold text-base transition-all duration-300 relative overflow-hidden',
          state === 'success'
            ? 'bg-green-500/10 border border-green-500/30 text-green-400'
            : hasEnoughBalance || !isSignedIn
            ? 'btn-gold text-black'
            : 'bg-[#1a1a1a] border border-[#262626] text-[#A0A0A0]'
        )}
      >
        {/* Shimmer on hover */}
        {(hasEnoughBalance || !isSignedIn) && state === 'idle' && (
          <span className="absolute inset-0 bg-gold-shimmer animate-shimmer opacity-0 hover:opacity-100" />
        )}

        <AnimatePresence mode="wait">
          {state === 'loading' ? (
            <motion.span
              key="loading"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="flex items-center gap-2"
            >
              <Loader2 size={18} className="animate-spin" />
              Unlocking…
            </motion.span>
          ) : state === 'success' ? (
            <motion.span
              key="success"
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="flex items-center gap-2"
            >
              <Unlock size={18} />
              Unlocked!
            </motion.span>
          ) : !isSignedIn ? (
            <motion.span
              key="signin"
              className="flex items-center gap-2"
            >
              <Lock size={18} />
              Sign In to Unlock
            </motion.span>
          ) : !hasEnoughBalance ? (
            <motion.span
              key="recharge"
              className="flex items-center gap-2"
            >
              <AlertCircle size={18} className="text-gold" />
              <span className="text-white">Recharge to Unlock</span>
            </motion.span>
          ) : (
            <motion.span
              key="unlock"
              className="flex items-center gap-2"
            >
              <Coins size={18} />
              Unlock for {coinPrice} Coins
            </motion.span>
          )}
        </AnimatePresence>
      </motion.button>

      {/* ─── Insufficient Funds Modal ─── */}
      <AnimatePresence>
        {showRechargeModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-end sm:items-center justify-center p-4"
            onClick={() => setShowRechargeModal(false)}
          >
            <motion.div
              initial={{ y: 60, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: 60, opacity: 0 }}
              transition={{ type: 'spring', damping: 25 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-[#111111] border border-[#262626] rounded-3xl p-8 w-full max-w-sm"
            >
              <div className="w-14 h-14 rounded-2xl bg-gold-muted border border-gold/20 flex items-center justify-center mb-6 mx-auto">
                <Coins size={24} className="text-gold" />
              </div>

              <h3 className="font-display text-2xl text-white text-center mb-2">
                Not Enough Coins
              </h3>
              <p className="text-[#A0A0A0] text-sm text-center mb-2">
                You need <span className="text-gold font-mono">{coinPrice}</span> coins to unlock this.
              </p>
              <p className="text-[#5A5A5A] text-xs text-center mb-8">
                Your balance: <span className="text-white font-mono">{walletBalance}</span> coins
              </p>

              <div className="space-y-3">
                <button
                  onClick={() => router.push('/wallet')}
                  className="btn-gold w-full py-3 rounded-2xl text-black font-semibold"
                >
                  Recharge Wallet
                </button>
                <button
                  onClick={() => setShowRechargeModal(false)}
                  className="w-full py-3 rounded-2xl text-[#A0A0A0] text-sm hover:text-white transition-colors"
                >
                  Cancel
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
