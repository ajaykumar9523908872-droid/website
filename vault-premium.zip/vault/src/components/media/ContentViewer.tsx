'use client';

import { useState } from 'react';
import Image from 'next/image';
import { motion, AnimatePresence } from 'framer-motion';
import { Lock, ZoomIn, Maximize2 } from 'lucide-react';
import type { Content } from '@/types';

interface ContentViewerProps {
  content: Content;
  isUnlocked: boolean;
  mediaUrl: string | null;
}

export default function ContentViewer({ content, isUnlocked, mediaUrl }: ContentViewerProps) {
  const [lightboxOpen, setLightboxOpen] = useState(false);
  const isVideo = content.type === 'video';

  return (
    <>
      <div className="relative rounded-2xl overflow-hidden bg-[#0d0d0d] border border-[#1a1a1a] aspect-video sm:aspect-auto sm:min-h-[500px]">
        {isVideo ? (
          <VideoPlayer
            content={content}
            isUnlocked={isUnlocked}
            mediaUrl={mediaUrl}
          />
        ) : (
          <ImageViewer
            content={content}
            isUnlocked={isUnlocked}
            mediaUrl={mediaUrl}
            onLightbox={() => setLightboxOpen(true)}
          />
        )}

        {/* Locked overlay */}
        {!isUnlocked && (
          <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/40 backdrop-blur-none z-10">
            <div className="text-center space-y-4">
              <div className="w-16 h-16 rounded-full border border-gold/30 bg-gold-muted flex items-center justify-center mx-auto">
                <Lock size={24} className="text-gold" />
              </div>
              <div>
                <div className="text-white font-semibold">Content Locked</div>
                <div className="text-[#5A5A5A] text-sm mt-1">
                  {isVideo ? 'Preview only. Unlock for full video.' : 'Unlock to view full image.'}
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Lightbox for images */}
      <AnimatePresence>
        {lightboxOpen && mediaUrl && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/95 flex items-center justify-center p-4"
            onClick={() => setLightboxOpen(false)}
          >
            <motion.div
              initial={{ scale: 0.9 }}
              animate={{ scale: 1 }}
              exit={{ scale: 0.9 }}
              className="relative max-w-5xl max-h-[90vh] w-full"
              onClick={(e) => e.stopPropagation()}
            >
              <Image
                src={mediaUrl}
                alt={content.title}
                width={1200}
                height={800}
                className="object-contain max-h-[85vh] w-auto mx-auto rounded-xl"
              />
              <button
                onClick={() => setLightboxOpen(false)}
                className="absolute top-4 right-4 w-10 h-10 rounded-full bg-black/80 border border-white/10 flex items-center justify-center text-white hover:bg-white/10 transition-colors"
              >
                ✕
              </button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}

// ─── Video Player ──────────────────────────────────────────────────
function VideoPlayer({
  content,
  isUnlocked,
  mediaUrl,
}: {
  content: Content;
  isUnlocked: boolean;
  mediaUrl: string | null;
}) {
  if (isUnlocked && content.mux_playback_id_signed) {
    return (
      <div className="w-full h-full">
        {/* Mux Player (import dynamically in real app) */}
        <div className="w-full aspect-video bg-black">
          <video
            src={mediaUrl ?? undefined}
            controls
            className="w-full h-full"
            playsInline
            controlsList="nodownload"
            onContextMenu={(e) => e.preventDefault()}
          />
        </div>
      </div>
    );
  }

  // Preview: show Mux thumbnail + play indicator (5s preview)
  return (
    <div className="relative w-full aspect-video bg-black flex items-center justify-center">
      {content.mux_playback_id && (
        // eslint-disable-next-line @next/next/no-img-element
        <img
          src={`https://image.mux.com/${content.mux_playback_id}/thumbnail.jpg`}
          alt={content.title}
          className="absolute inset-0 w-full h-full object-cover blur-lg scale-110"
        />
      )}
      <div className="relative z-10 text-center">
        <div className="text-white text-sm opacity-70">5s Preview Available</div>
      </div>
    </div>
  );
}

// ─── Image Viewer ──────────────────────────────────────────────────
function ImageViewer({
  content,
  isUnlocked,
  mediaUrl,
  onLightbox,
}: {
  content: Content;
  isUnlocked: boolean;
  mediaUrl: string | null;
  onLightbox: () => void;
}) {
  const src = isUnlocked ? mediaUrl : null;

  return (
    <div className="relative min-h-[400px] sm:min-h-[600px] flex items-center justify-center">
      {src ? (
        <>
          <Image
            src={src}
            alt={content.title}
            fill
            className="object-contain"
            sizes="(max-width: 1024px) 100vw, 65vw"
            onContextMenu={(e) => e.preventDefault()}
          />
          {/* Controls */}
          <div className="absolute bottom-4 right-4 flex gap-2 z-20">
            <button
              onClick={onLightbox}
              className="w-9 h-9 rounded-xl bg-black/70 backdrop-blur-sm border border-white/10 flex items-center justify-center text-white hover:bg-white/10 transition-colors"
            >
              <Maximize2 size={15} />
            </button>
          </div>
        </>
      ) : (
        /* Blurred placeholder */
        <div className="absolute inset-0 bg-gradient-to-br from-[#1a1a1a] to-[#0d0d0d] flex items-center justify-center">
          <Lock size={48} className="text-[#2a2a2a]" />
        </div>
      )}
    </div>
  );
}
