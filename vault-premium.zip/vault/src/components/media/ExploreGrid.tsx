import ContentCard from './ContentCard';
import { createServerSupabase } from '@/lib/supabase';
import type { ContentWithUnlock } from '@/types';

interface ExploreGridProps {
  type: 'all' | 'image' | 'video';
  sort: 'newest' | 'popular' | 'price_asc' | 'price_desc';
  premium: boolean;
  unlockedIds: string[];
}

export default async function ExploreGrid({
  type,
  sort,
  premium,
  unlockedIds,
}: ExploreGridProps) {
  const supabase = createServerSupabase();

  let query = supabase
    .from('content')
    .select('*')
    .eq('status', 'published');

  if (type !== 'all') {
    query = query.eq('type', type);
  }
  if (premium) {
    query = query.eq('is_premium', true);
  }

  switch (sort) {
    case 'popular':
      query = query.order('unlock_count', { ascending: false });
      break;
    case 'price_asc':
      query = query.order('coin_price', { ascending: true });
      break;
    case 'price_desc':
      query = query.order('coin_price', { ascending: false });
      break;
    default:
      query = query.order('created_at', { ascending: false });
  }

  query = query.limit(48);

  const { data, error } = await query;

  if (error) {
    return (
      <div className="text-center py-20 text-[#5A5A5A]">
        Failed to load content. Please try again.
      </div>
    );
  }

  if (!data || data.length === 0) {
    return (
      <div className="text-center py-32">
        <p className="text-[#5A5A5A] text-lg">No content found.</p>
        <p className="text-[#3a3a3a] text-sm mt-2">Check back soon for new uploads.</p>
      </div>
    );
  }

  const contentWithUnlock: ContentWithUnlock[] = data.map((item) => ({
    ...item,
    is_unlocked: unlockedIds.includes(item.id),
    unlocked_at: null,
    thumbnail_url: item.thumbnail_key
      ? `${process.env.NEXT_PUBLIC_APP_URL}/api/content/thumbnail/${item.id}`
      : null,
  }));

  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 mt-6">
      {contentWithUnlock.map((item, i) => (
        <ContentCard
          key={item.id}
          content={item}
          priority={i < 8}
        />
      ))}
    </div>
  );
}
