'use client';

import Link from 'next/link';
import Image from 'next/image';
import { motion } from 'framer-motion';
import { Lock, Play, Coins, CheckCircle2, Eye, Clock } from 'lucide-react';
import { cn, formatCoins, formatDuration, truncate } from '@/lib/utils';
import type { ContentWithUnlock } from '@/types';

interface ContentCardProps {
  content: ContentWithUnlock;
  priority?: boolean;
  style?: React.CSSProperties;
  className?: string;
}

export default function ContentCard({
  content,
  priority = false,
  style,
  className,
}: ContentCardProps) {
  const isVideo = content.type === 'video';
  const isUnlocked = content.is_unlocked;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
      style={style}
      className={cn('group relative', className)}
    >
      <Link href={`/content/${content.id}`} className="block">
        {/* ─── Thumbnail ─── */}
        <div className="relative aspect-[3/4] overflow-hidden rounded-2xl bg-[#111111] mb-3">
          {/* Premium badge */}
          {content.is_premium && (
            <div className="absolute top-3 left-3 z-20 badge-gold text-[10px]">
              PREMIUM
            </div>
          )}

          {/* Type indicator */}
          <div className="absolute top-3 right-3 z-20">
            {isVideo ? (
              <div className="w-7 h-7 rounded-full bg-black/70 backdrop-blur-sm flex items-center justify-center border border-white/10">
                <Play size={12} className="text-white ml-0.5" fill="white" />
              </div>
            ) : null}
          </div>

          {/* Duration for videos */}
          {isVideo && content.duration_seconds && (
            <div className="absolute bottom-3 right-3 z-20 bg-black/80 backdrop-blur-sm rounded-md px-2 py-0.5 text-xs font-mono text-white">
              {formatDuration(content.duration_seconds)}
            </div>
          )}

          {/* Thumbnail image */}
          {content.thumbnail_url ? (
            <Image
              src={content.thumbnail_url}
              alt={content.title}
              fill
              className={cn(
                'object-cover transition-transform duration-500 group-hover:scale-105',
                !isUnlocked && 'blur-sm scale-110'
              )}
              priority={priority}
              sizes="(max-width: 640px) 50vw, (max-width: 1024px) 33vw, 25vw"
            />
          ) : (
            // Placeholder with gradient
            <div className="absolute inset-0 bg-gradient-to-br from-[#1a1a1a] to-[#0d0d0d] flex items-center justify-center">
              <div className="text-[#2a2a2a]">
                {isVideo ? <Play size={40} /> : <Eye size={40} />}
              </div>
            </div>
          )}

          {/* Lock / Unlock overlay */}
          <div className="absolute inset-0 bg-card-gradient" />
          <div
            className={cn(
              'absolute inset-0 flex items-center justify-center transition-all duration-300',
              isUnlocked
                ? 'opacity-0 group-hover:opacity-0'
                : 'opacity-100'
            )}
          >
            {!isUnlocked && (
              <div className="flex flex-col items-center gap-2">
                <div className="w-10 h-10 rounded-full bg-black/60 backdrop-blur-sm border border-white/10 flex items-center justify-center">
                  <Lock size={16} className="text-white" />
                </div>
              </div>
            )}
          </div>

          {/* Unlocked check */}
          {isUnlocked && (
            <div className="absolute top-3 left-3 z-20">
              <CheckCircle2 size={18} className="text-gold" fill="rgba(212,175,55,0.2)" />
            </div>
          )}

          {/* Hover overlay */}
          <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors duration-300" />
        </div>

        {/* ─── Info ─── */}
        <div className="px-1">
          <h3 className="text-sm font-medium text-white leading-tight mb-1 group-hover:text-gold transition-colors duration-200">
            {truncate(content.title, 40)}
          </h3>

          <div className="flex items-center justify-between">
            {isUnlocked ? (
              <span className="text-xs text-gold flex items-center gap-1">
                <CheckCircle2 size={11} />
                Unlocked
              </span>
            ) : (
              <div className="coin-display">
                <Coins size={11} />
                {formatCoins(content.coin_price)}
              </div>
            )}

            <span className="text-xs text-[#5A5A5A]">
              {content.unlock_count > 0 && `${content.unlock_count} unlocks`}
            </span>
          </div>
        </div>
      </Link>
    </motion.div>
  );
}
