import { cn } from '@/lib/utils';
import type { LucideIcon } from 'lucide-react';

interface StatCardProps {
  label: string;
  value: string;
  icon: LucideIcon;
  trend?: string;
  gold?: boolean;
}

export default function StatCard({ label, value, icon: Icon, trend, gold }: StatCardProps) {
  return (
    <div className={cn(
      'vault-card p-5',
      gold && 'border-gold/20 bg-gradient-to-br from-[#1a1500] to-[#111111]'
    )}>
      <div className="flex items-start justify-between mb-4">
        <div className={cn(
          'w-9 h-9 rounded-xl flex items-center justify-center',
          gold ? 'bg-gold/15 border border-gold/25' : 'bg-white/5 border border-white/10'
        )}>
          <Icon size={16} className={gold ? 'text-gold' : 'text-[#A0A0A0]'} />
        </div>
      </div>
      <div className={cn(
        'font-display text-3xl font-light mb-1',
        gold ? 'text-gold' : 'text-white'
      )}>
        {value}
      </div>
      <div className="text-xs text-[#5A5A5A] uppercase tracking-wide">{label}</div>
      {trend && <div className="text-xs text-emerald-400 mt-1">{trend}</div>}
    </div>
  );
}
