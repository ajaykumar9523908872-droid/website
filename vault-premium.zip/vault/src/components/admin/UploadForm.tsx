'use client';

import { useState, useRef, useCallback } from 'react';
import { useRouter } from 'next/navigation';
import { motion, AnimatePresence } from 'framer-motion';
import { Upload, Image, Video, X, Loader2, CheckCircle2, Tag, Coins, Crown } from 'lucide-react';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';

interface FormState {
  title: string;
  description: string;
  coinPrice: string;
  type: 'image' | 'video';
  isFeatured: boolean;
  isPremium: boolean;
  tags: string;
  status: 'draft' | 'published';
}

type UploadState = 'idle' | 'uploading' | 'processing' | 'done' | 'error';

export default function UploadForm() {
  const router = useRouter();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [uploadState, setUploadState] = useState<UploadState>('idle');
  const [uploadProgress, setUploadProgress] = useState(0);
  const [isDragging, setIsDragging] = useState(false);

  const [form, setForm] = useState<FormState>({
    title: '',
    description: '',
    coinPrice: '10',
    type: 'image',
    isFeatured: false,
    isPremium: false,
    tags: '',
    status: 'published',
  });

  const handleFileSelect = useCallback((selectedFile: File) => {
    const isImage = selectedFile.type.startsWith('image/');
    const isVideo = selectedFile.type.startsWith('video/');

    if (!isImage && !isVideo) {
      toast.error('Only images and videos are supported.');
      return;
    }

    if (selectedFile.size > 500 * 1024 * 1024) { // 500MB limit
      toast.error('File too large. Maximum 500MB.');
      return;
    }

    setFile(selectedFile);
    setForm((f) => ({
      ...f,
      type: isImage ? 'image' : 'video',
      coinPrice: isImage ? '10' : '50',
      title: f.title || selectedFile.name.replace(/\.[^/.]+$/, ''),
    }));

    if (isImage) {
      const url = URL.createObjectURL(selectedFile);
      setPreview(url);
    } else {
      setPreview(null);
    }
  }, []);

  const handleDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault();
      setIsDragging(false);
      const dropped = e.dataTransfer.files[0];
      if (dropped) handleFileSelect(dropped);
    },
    [handleFileSelect]
  );

  const handleSubmit = async () => {
    if (!file || !form.title.trim()) {
      toast.error('Please fill in the title and select a file.');
      return;
    }

    setUploadState('uploading');
    setUploadProgress(0);

    try {
      // Step 1: Get signed upload URL from our API
      const initRes = await fetch('/api/admin/content', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: form.title.trim(),
          description: form.description.trim() || null,
          coinPrice: parseInt(form.coinPrice),
          type: form.type,
          isFeatured: form.isFeatured,
          isPremium: form.isPremium,
          tags: form.tags.split(',').map((t) => t.trim()).filter(Boolean),
          status: form.status,
          fileName: file.name,
          fileType: file.type,
          fileSize: file.size,
        }),
      });

      if (!initRes.ok) {
        const err = await initRes.json();
        throw new Error(err.error ?? 'Failed to initialize upload');
      }

      const { uploadUrl, contentId } = await initRes.json();

      // Step 2: Upload directly to R2 (or Mux for video)
      const xhr = new XMLHttpRequest();
      xhr.upload.addEventListener('progress', (e) => {
        if (e.lengthComputable) {
          setUploadProgress(Math.round((e.loaded / e.total) * 100));
        }
      });

      await new Promise<void>((resolve, reject) => {
        xhr.onload = () => (xhr.status < 400 ? resolve() : reject(new Error('Upload failed')));
        xhr.onerror = () => reject(new Error('Network error'));
        xhr.open('PUT', uploadUrl);
        xhr.setRequestHeader('Content-Type', file.type);
        xhr.send(file);
      });

      setUploadState('processing');

      // Step 3: Confirm upload is complete
      await fetch(`/api/admin/content/${contentId}/confirm`, { method: 'POST' });

      setUploadState('done');
      toast.success('Content uploaded successfully!');
      setTimeout(() => router.push('/admin'), 1500);
    } catch (err) {
      console.error(err);
      setUploadState('error');
      toast.error(err instanceof Error ? err.message : 'Upload failed');
    }
  };

  const resetFile = () => {
    setFile(null);
    setPreview(null);
    setUploadState('idle');
    setUploadProgress(0);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  return (
    <div className="space-y-6">
      {/* ─── Drop Zone ─── */}
      <div
        onDragOver={(e) => { e.preventDefault(); setIsDragging(true); }}
        onDragLeave={() => setIsDragging(false)}
        onDrop={handleDrop}
        onClick={() => !file && fileInputRef.current?.click()}
        className={cn(
          'relative rounded-2xl border-2 border-dashed transition-all duration-300 cursor-pointer',
          isDragging
            ? 'border-gold bg-gold-muted scale-[1.01]'
            : file
            ? 'border-[#262626] cursor-default'
            : 'border-[#262626] hover:border-gold/40 hover:bg-white/[0.02]'
        )}
      >
        {file ? (
          <div className="p-4">
            <div className="flex items-start gap-4">
              {/* Preview */}
              {preview ? (
                // eslint-disable-next-line @next/next/no-img-element
                <img
                  src={preview}
                  alt="Preview"
                  className="w-20 h-20 rounded-xl object-cover shrink-0"
                />
              ) : (
                <div className="w-20 h-20 rounded-xl bg-[#1a1a1a] border border-[#262626] flex items-center justify-center shrink-0">
                  <Video size={24} className="text-[#5A5A5A]" />
                </div>
              )}

              <div className="flex-1 min-w-0">
                <div className="text-sm font-medium text-white truncate">{file.name}</div>
                <div className="text-xs text-[#5A5A5A] mt-1">
                  {(file.size / (1024 * 1024)).toFixed(1)} MB · {form.type}
                </div>

                {/* Progress bar */}
                {uploadState === 'uploading' && (
                  <div className="mt-3">
                    <div className="flex justify-between text-xs text-[#5A5A5A] mb-1">
                      <span>Uploading…</span>
                      <span>{uploadProgress}%</span>
                    </div>
                    <div className="h-1.5 bg-[#1a1a1a] rounded-full overflow-hidden">
                      <motion.div
                        className="h-full bg-gold rounded-full"
                        initial={{ width: 0 }}
                        animate={{ width: `${uploadProgress}%` }}
                        transition={{ duration: 0.3 }}
                      />
                    </div>
                  </div>
                )}

                {uploadState === 'processing' && (
                  <div className="flex items-center gap-2 mt-2 text-xs text-[#A0A0A0]">
                    <Loader2 size={12} className="animate-spin" />
                    Processing…
                  </div>
                )}

                {uploadState === 'done' && (
                  <div className="flex items-center gap-2 mt-2 text-xs text-emerald-400">
                    <CheckCircle2 size={12} />
                    Upload complete!
                  </div>
                )}
              </div>

              {uploadState === 'idle' && (
                <button
                  onClick={(e) => { e.stopPropagation(); resetFile(); }}
                  className="p-1.5 rounded-lg hover:bg-white/5 text-[#5A5A5A] hover:text-white transition-colors shrink-0"
                >
                  <X size={14} />
                </button>
              )}
            </div>
          </div>
        ) : (
          <div className="py-14 flex flex-col items-center justify-center gap-3">
            <div className={cn(
              'w-14 h-14 rounded-2xl border flex items-center justify-center transition-colors',
              isDragging
                ? 'border-gold/50 bg-gold/10'
                : 'border-[#262626] bg-[#111111]'
            )}>
              <Upload size={22} className={isDragging ? 'text-gold' : 'text-[#5A5A5A]'} />
            </div>
            <div className="text-center">
              <div className="text-white text-sm font-medium">Drop file here or click to browse</div>
              <div className="text-[#5A5A5A] text-xs mt-1">Images & videos · Max 500MB</div>
            </div>
            <div className="flex gap-2 mt-1">
              {['JPG', 'PNG', 'WEBP', 'MP4', 'MOV'].map((ext) => (
                <span key={ext} className="text-[10px] text-[#3a3a3a] border border-[#1a1a1a] rounded px-1.5 py-0.5">
                  {ext}
                </span>
              ))}
            </div>
          </div>
        )}
      </div>

      <input
        ref={fileInputRef}
        type="file"
        accept="image/*,video/*"
        className="hidden"
        onChange={(e) => e.target.files?.[0] && handleFileSelect(e.target.files[0])}
      />

      {/* ─── Form Fields ─── */}
      <div className="space-y-4">
        {/* Title */}
        <div>
          <label className="block text-xs text-[#5A5A5A] uppercase tracking-wide mb-2">
            Title *
          </label>
          <input
            type="text"
            value={form.title}
            onChange={(e) => setForm((f) => ({ ...f, title: e.target.value }))}
            placeholder="Enter content title"
            className="vault-input"
          />
        </div>

        {/* Description */}
        <div>
          <label className="block text-xs text-[#5A5A5A] uppercase tracking-wide mb-2">
            Description
          </label>
          <textarea
            value={form.description}
            onChange={(e) => setForm((f) => ({ ...f, description: e.target.value }))}
            placeholder="Optional description…"
            rows={3}
            className="vault-input resize-none"
          />
        </div>

        {/* Price & Status row */}
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-xs text-[#5A5A5A] uppercase tracking-wide mb-2">
              Coin Price
            </label>
            <div className="relative">
              <Coins size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-gold" />
              <input
                type="number"
                value={form.coinPrice}
                onChange={(e) => setForm((f) => ({ ...f, coinPrice: e.target.value }))}
                min="1"
                className="vault-input pl-9"
              />
            </div>
            {form.coinPrice && (
              <div className="text-xs text-[#5A5A5A] mt-1">
                ≈ €{(parseInt(form.coinPrice) / 100).toFixed(2)}
              </div>
            )}
          </div>

          <div>
            <label className="block text-xs text-[#5A5A5A] uppercase tracking-wide mb-2">
              Status
            </label>
            <select
              value={form.status}
              onChange={(e) => setForm((f) => ({ ...f, status: e.target.value as 'draft' | 'published' }))}
              className="vault-input"
            >
              <option value="published">Published</option>
              <option value="draft">Draft</option>
            </select>
          </div>
        </div>

        {/* Tags */}
        <div>
          <label className="block text-xs text-[#5A5A5A] uppercase tracking-wide mb-2">
            Tags (comma-separated)
          </label>
          <div className="relative">
            <Tag size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#5A5A5A]" />
            <input
              type="text"
              value={form.tags}
              onChange={(e) => setForm((f) => ({ ...f, tags: e.target.value }))}
              placeholder="portrait, exclusive, new"
              className="vault-input pl-9"
            />
          </div>
        </div>

        {/* Toggles */}
        <div className="flex gap-4">
          {[
            { key: 'isFeatured', label: 'Featured', icon: '⭐' },
            { key: 'isPremium', label: 'Premium', icon: '👑' },
          ].map(({ key, label, icon }) => (
            <button
              key={key}
              onClick={() => setForm((f) => ({ ...f, [key]: !f[key as keyof FormState] }))}
              className={cn(
                'flex items-center gap-2 px-4 py-2 rounded-xl border text-sm transition-all duration-200',
                form[key as keyof FormState]
                  ? 'border-gold bg-gold-muted text-gold'
                  : 'border-[#262626] bg-[#111111] text-[#5A5A5A] hover:text-white'
              )}
            >
              <span>{icon}</span>
              {label}
            </button>
          ))}
        </div>
      </div>

      {/* ─── Submit ─── */}
      <motion.button
        onClick={handleSubmit}
        disabled={!file || !form.title.trim() || uploadState === 'uploading' || uploadState === 'processing' || uploadState === 'done'}
        whileTap={{ scale: 0.98 }}
        className="btn-gold w-full py-4 rounded-2xl text-black font-semibold text-base flex items-center justify-center gap-2 disabled:opacity-40 disabled:cursor-not-allowed disabled:hover:transform-none"
      >
        {uploadState === 'uploading' ? (
          <><Loader2 size={18} className="animate-spin" /> Uploading… {uploadProgress}%</>
        ) : uploadState === 'processing' ? (
          <><Loader2 size={18} className="animate-spin" /> Processing…</>
        ) : uploadState === 'done' ? (
          <><CheckCircle2 size={18} /> Done!</>
        ) : (
          <><Upload size={18} /> Upload Content</>
        )}
      </motion.button>
    </div>
  );
}
