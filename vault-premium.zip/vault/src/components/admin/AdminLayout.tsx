'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { Crown, LayoutDashboard, Upload, Users, BarChart2, LogOut, Settings } from 'lucide-react';
import { cn } from '@/lib/utils';
import { UserButton } from '@clerk/nextjs';

const navItems = [
  { href: '/admin', label: 'Dashboard', icon: LayoutDashboard, exact: true },
  { href: '/admin/upload', label: 'Upload Content', icon: Upload },
  { href: '/admin/users', label: 'Users', icon: Users },
  { href: '/admin/analytics', label: 'Analytics', icon: BarChart2 },
  { href: '/admin/settings', label: 'Settings', icon: Settings },
];

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();

  return (
    <div className="flex min-h-screen">
      {/* ─── Sidebar ─── */}
      <aside className="w-64 shrink-0 bg-[#0d0d0d] border-r border-[#1a1a1a] flex flex-col fixed inset-y-0 left-0 z-40">
        {/* Logo */}
        <div className="px-6 py-6 border-b border-[#1a1a1a]">
          <div className="flex items-center gap-2">
            <Crown size={18} className="text-gold" />
            <span className="font-display text-lg tracking-[0.2em] text-white">VAULT</span>
          </div>
          <div className="badge-gold mt-2 text-[10px]">ADMIN PANEL</div>
        </div>

        {/* Nav */}
        <nav className="flex-1 px-3 py-4 space-y-1">
          {navItems.map(({ href, label, icon: Icon, exact }) => {
            const active = exact ? pathname === href : pathname.startsWith(href);
            return (
              <Link
                key={href}
                href={href}
                className={cn(
                  'flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all duration-200',
                  active
                    ? 'bg-gold-muted text-gold border border-gold/20'
                    : 'text-[#5A5A5A] hover:text-white hover:bg-white/5'
                )}
              >
                <Icon size={16} />
                {label}
              </Link>
            );
          })}
        </nav>

        {/* Bottom */}
        <div className="px-4 py-4 border-t border-[#1a1a1a]">
          <div className="flex items-center gap-3">
            <UserButton appearance={{
              elements: { avatarBox: 'w-8 h-8' }
            }} />
            <div>
              <div className="text-xs text-white font-medium">Admin</div>
              <Link href="/" className="text-xs text-[#5A5A5A] hover:text-white transition-colors flex items-center gap-1">
                <LogOut size={10} />
                Back to site
              </Link>
            </div>
          </div>
        </div>
      </aside>

      {/* ─── Main Content ─── */}
      <main className="flex-1 ml-64 min-h-screen bg-background">
        <div className="p-8 max-w-6xl">{children}</div>
      </main>
    </div>
  );
}
