'use client';

import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from 'recharts';
import { format, parseISO } from 'date-fns';

interface DailyRevenueRow {
  day: string;
  payment_count: number;
  total_cents: number;
  total_coins: number;
}

interface RevenueChartProps {
  data: DailyRevenueRow[];
}

export default function RevenueChart({ data }: RevenueChartProps) {
  const chartData = [...data].reverse().map((row) => ({
    day: format(parseISO(row.day), 'MMM d'),
    revenue: row.total_cents / 100,
    payments: row.payment_count,
  }));

  return (
    <ResponsiveContainer width="100%" height={240}>
      <AreaChart data={chartData} margin={{ top: 0, right: 0, left: -10, bottom: 0 }}>
        <defs>
          <linearGradient id="revenueGrad" x1="0" y1="0" x2="0" y2="1">
            <stop offset="5%" stopColor="#D4AF37" stopOpacity={0.3} />
            <stop offset="95%" stopColor="#D4AF37" stopOpacity={0} />
          </linearGradient>
        </defs>
        <CartesianGrid strokeDasharray="3 3" stroke="#1a1a1a" vertical={false} />
        <XAxis
          dataKey="day"
          tick={{ fill: '#5A5A5A', fontSize: 11 }}
          axisLine={false}
          tickLine={false}
          interval="preserveStartEnd"
        />
        <YAxis
          tick={{ fill: '#5A5A5A', fontSize: 11 }}
          axisLine={false}
          tickLine={false}
          tickFormatter={(v) => `€${v}`}
        />
        <Tooltip
          contentStyle={{
            background: '#111111',
            border: '1px solid #262626',
            borderRadius: '12px',
            color: '#fff',
            fontSize: 12,
          }}
          formatter={(value: number) => [`€${value.toFixed(2)}`, 'Revenue']}
          labelStyle={{ color: '#A0A0A0', marginBottom: 4 }}
        />
        <Area
          type="monotone"
          dataKey="revenue"
          stroke="#D4AF37"
          strokeWidth={2}
          fill="url(#revenueGrad)"
          dot={false}
          activeDot={{ r: 4, fill: '#D4AF37', strokeWidth: 0 }}
        />
      </AreaChart>
    </ResponsiveContainer>
  );
}
