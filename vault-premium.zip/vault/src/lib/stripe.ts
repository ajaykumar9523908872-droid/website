import Stripe from 'stripe';
import type { RechargePackage } from '@/types';

export const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
  apiVersion: '2024-04-10',
  typescript: true,
});

// ─── Recharge packages (also stored in DB admin_settings) ─────────
export const RECHARGE_PACKAGES: RechargePackage[] = [
  { coins: 100, price_cents: 100, label: 'Starter' },
  { coins: 300, price_cents: 280, label: 'Popular', badge: 'Best Value' },
  { coins: 1000, price_cents: 850, label: 'Premium', badge: 'Save 15%' },
];

// ─── Create Stripe checkout session for wallet recharge ───────────
export async function createRechargeSession(
  userId: string,
  userEmail: string,
  coins: number,
  priceCents: number,
  successUrl: string,
  cancelUrl: string
) {
  const session = await stripe.checkout.sessions.create({
    mode: 'payment',
    customer_email: userEmail,
    line_items: [
      {
        price_data: {
          currency: 'eur',
          product_data: {
            name: `${coins} Vault Coins`,
            description: `Unlock premium content on VAULT. ${coins} coins = €${(coins / 100).toFixed(2)} in value.`,
            images: [],
          },
          unit_amount: priceCents,
        },
        quantity: 1,
      },
    ],
    payment_method_types: ['card', 'paypal'],
    success_url: successUrl,
    cancel_url: cancelUrl,
    metadata: {
      user_id: userId,
      coins: String(coins),
    },
    payment_intent_data: {
      metadata: {
        user_id: userId,
        coins: String(coins),
      },
    },
  });

  return session;
}

// ─── Verify Stripe webhook signature ─────────────────────────────
export function constructWebhookEvent(
  payload: string | Buffer,
  signature: string
): Stripe.Event {
  return stripe.webhooks.constructEvent(
    payload,
    signature,
    process.env.STRIPE_WEBHOOK_SECRET!
  );
}
