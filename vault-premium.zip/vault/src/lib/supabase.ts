import { createClient } from '@supabase/supabase-js';
import { createBrowserClient, createServerClient } from '@supabase/ssr';
import { cookies } from 'next/headers';
import type { Database } from '@/types';

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!;
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!;
const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY!;

// ─── Browser client (for client components) ───────────────────────
export function createBrowserSupabase() {
  return createBrowserClient<Database>(supabaseUrl, supabaseAnonKey);
}

// ─── Server client (for Server Components / Route Handlers) ───────
export function createServerSupabase() {
  const cookieStore = cookies();
  return createServerClient<Database>(supabaseUrl, supabaseAnonKey, {
    cookies: {
      get(name: string) {
        return cookieStore.get(name)?.value;
      },
    },
  });
}

// ─── Admin client (bypasses RLS — server only!) ───────────────────
export const supabaseAdmin = createClient<Database>(
  supabaseUrl,
  supabaseServiceKey,
  {
    auth: {
      autoRefreshToken: false,
      persistSession: false,
    },
  }
);

// ─── Helper: get or create user record ───────────────────────────
export async function getOrCreateUser(clerkId: string, email: string, displayName?: string) {
  const { data: existing } = await supabaseAdmin
    .from('users')
    .select('*')
    .eq('clerk_id', clerkId)
    .single();

  if (existing) {
    await supabaseAdmin
      .from('users')
      .update({ last_seen_at: new Date().toISOString() })
      .eq('clerk_id', clerkId);
    return existing;
  }

  const { data: newUser, error } = await supabaseAdmin
    .from('users')
    .insert({
      clerk_id: clerkId,
      email,
      display_name: displayName ?? null,
    })
    .select()
    .single();

  if (error) throw error;
  return newUser;
}

// ─── Helper: get user by clerk ID ────────────────────────────────
export async function getUserByClerkId(clerkId: string) {
  const { data, error } = await supabaseAdmin
    .from('users')
    .select('*')
    .eq('clerk_id', clerkId)
    .single();

  if (error) return null;
  return data;
}

// ─── Helper: get wallet balance ───────────────────────────────────
export async function getWalletBalance(userId: string): Promise<number> {
  const { data } = await supabaseAdmin
    .from('wallet')
    .select('balance')
    .eq('user_id', userId)
    .single();
  return data?.balance ?? 0;
}
