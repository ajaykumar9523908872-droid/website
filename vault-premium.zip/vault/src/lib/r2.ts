import {
  S3Client,
  PutObjectCommand,
  GetObjectCommand,
  DeleteObjectCommand,
} from '@aws-sdk/client-s3';
import { getSignedUrl } from '@aws-sdk/s3-request-presigner';

const R2 = new S3Client({
  region: 'auto',
  endpoint: `https://${process.env.R2_ACCOUNT_ID}.r2.cloudflarestorage.com`,
  credentials: {
    accessKeyId: process.env.R2_ACCESS_KEY_ID!,
    secretAccessKey: process.env.R2_SECRET_ACCESS_KEY!,
  },
});

const BUCKET = process.env.R2_BUCKET_NAME!;
const PUBLIC_DOMAIN = process.env.R2_PUBLIC_DOMAIN!;

// ─── Get a signed URL for reading (short-lived, per-session) ─────
export async function getSignedReadUrl(
  key: string,
  expiresInSeconds = 3600
): Promise<string> {
  const command = new GetObjectCommand({
    Bucket: BUCKET,
    Key: key,
    // Prevent hotlinking by requiring exact origin
    ResponseContentDisposition: 'inline',
  });

  return getSignedUrl(R2, command, { expiresIn: expiresInSeconds });
}

// ─── Get a signed URL for uploading ──────────────────────────────
export async function getSignedUploadUrl(
  key: string,
  contentType: string,
  expiresInSeconds = 300
): Promise<string> {
  const command = new PutObjectCommand({
    Bucket: BUCKET,
    Key: key,
    ContentType: contentType,
    Metadata: {
      'uploaded-at': new Date().toISOString(),
    },
  });

  return getSignedUrl(R2, command, { expiresIn: expiresInSeconds });
}

// ─── Delete object from R2 ────────────────────────────────────────
export async function deleteFromR2(key: string): Promise<void> {
  await R2.send(new DeleteObjectCommand({ Bucket: BUCKET, Key: key }));
}

// ─── Generate storage key for content ────────────────────────────
export function generateContentKey(
  contentId: string,
  type: 'image' | 'video',
  variant: 'original' | 'thumbnail' | 'watermarked' = 'original'
): string {
  const timestamp = Date.now();
  return `content/${type}s/${contentId}/${variant}-${timestamp}`;
}

// ─── Public URL (for thumbnails that can be public) ───────────────
export function getPublicUrl(key: string): string {
  return `${PUBLIC_DOMAIN}/${key}`;
}

// ─── Thumbnail blur placeholder data URL ─────────────────────────
export function getBlurDataUrl(blurHash: string): string {
  // Return a tiny base64 placeholder
  // In production, decode BlurHash to a data: URL
  return `data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAYEBQYFBAYGBQYHBwYIChAKCgkJChQODwwQFxQYGBcUFhYaHSUfGhsjHBYWICwgIyYnKSopGR8tMC0oMCUoKSj/2wBDAQcHBwoIChMKChMoGhYaKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCj/wAARCAABAAEDASIAAhEBAxEB/8QAFAABAAAAAAAAAAAAAAAAAAAACf/EABQQAQAAAAAAAAAAAAAAAAAAAAD/xAAUAQEAAAAAAAAAAAAAAAAAAAAA/8QAFBEBAAAAAAAAAAAAAAAAAAAAAP/aAAwDAQACEQMRAD8AJQAB/9k=`;
}
