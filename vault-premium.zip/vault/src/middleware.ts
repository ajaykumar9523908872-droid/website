import { clerkMiddleware, createRouteMatcher } from '@clerk/nextjs/server';
import { NextResponse } from 'next/server';

// Routes that require authentication
const protectedRoutes = createRouteMatcher([
  '/wallet(.*)',
  '/profile(.*)',
  '/api/unlock(.*)',
  '/api/recharge(.*)',
]);

// Routes that require admin
const adminRoutes = createRouteMatcher([
  '/admin(.*)',
  '/api/admin(.*)',
]);

export default clerkMiddleware((auth, req) => {
  // Protect user routes
  if (protectedRoutes(req)) {
    auth().protect();
  }

  // Admin routes: protect and check admin flag
  if (adminRoutes(req)) {
    auth().protect();
    const userId = auth().userId;
    if (userId !== process.env.ADMIN_USER_ID) {
      return NextResponse.redirect(new URL('/', req.url));
    }
  }
});

export const config = {
  matcher: [
    // Skip static files and Next.js internals
    '/((?!_next|[^?]*\\.(?:html?|css|js(?!on)|jpe?g|webp|png|gif|svg|ttf|woff2?|ico|csv|docx?|xlsx?|zip|webmanifest)).*)',
    '/(api|trpc)(.*)',
  ],
};
