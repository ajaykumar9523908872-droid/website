# VAULT — Premium Content Platform

A luxury dark-mode content platform where the owner uploads exclusive images and videos. Users recharge a coin wallet and unlock content permanently.

**Business model:** Recharge → Wallet → Tap Unlock → View

---

## Tech Stack

| Layer | Technology |
|-------|-----------|
| Frontend | Next.js 14 (App Router) + TypeScript |
| Styling | Tailwind CSS + Framer Motion |
| Auth | Clerk |
| Database | Supabase (PostgreSQL) |
| Storage | Cloudflare R2 |
| Video | Mux |
| Payments | Stripe |
| Deployment | Vercel |

---

## Quick Start

### 1. Clone & Install

```bash
git clone https://github.com/yourname/vault.git
cd vault
npm install
```

### 2. Configure Environment

```bash
cp .env.example .env.local
```

Fill in all values in `.env.local` (see section below).

### 3. Set Up Supabase

```bash
# Install Supabase CLI
npm install -g supabase

# Login
supabase login

# Link your project
supabase link --project-ref YOUR_PROJECT_REF

# Run migrations
supabase db push
# or manually run: supabase/migrations/001_schema.sql in the SQL editor
```

### 4. Configure Clerk

1. Create app at [clerk.com](https://clerk.com)
2. Copy publishable key and secret key to `.env.local`
3. In Clerk dashboard → Webhooks → Add endpoint:
   - URL: `https://yourdomain.com/api/clerk-webhook`
   - Events: `user.created`, `user.updated`, `user.deleted`
4. Set `CLERK_WEBHOOK_SECRET` in `.env.local`
5. Get your own user ID from Clerk dashboard → Users, set as `ADMIN_USER_ID`

### 5. Configure Stripe

```bash
# Install Stripe CLI
brew install stripe/stripe-cli/stripe  # macOS

# Login
stripe login

# Forward webhooks locally
stripe listen --forward-to localhost:3000/api/webhook
```

1. Copy webhook secret shown in terminal to `STRIPE_WEBHOOK_SECRET`
2. In Stripe dashboard, add production webhook for:
   - `checkout.session.completed`
   - `payment_intent.payment_failed`

### 6. Configure Cloudflare R2

1. Log in to [Cloudflare dashboard](https://dash.cloudflare.com)
2. Go to R2 → Create bucket named `vault-media`
3. Create API token with Object Read & Write
4. Copy Account ID, Access Key ID, Secret Access Key
5. (Optional) Add custom domain to bucket for CDN

### 7. Configure Mux (for video)

1. Sign up at [mux.com](https://mux.com)
2. Create API Access Token with Full Access
3. Copy Token ID and Secret to `.env.local`

### 8. Run Locally

```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000)

---

## Environment Variables

```env
# Clerk
NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY=pk_live_...
CLERK_SECRET_KEY=sk_live_...
CLERK_WEBHOOK_SECRET=whsec_...
NEXT_PUBLIC_CLERK_SIGN_IN_URL=/login
NEXT_PUBLIC_CLERK_SIGN_UP_URL=/signup
NEXT_PUBLIC_CLERK_AFTER_SIGN_IN_URL=/explore
NEXT_PUBLIC_CLERK_AFTER_SIGN_UP_URL=/explore

# Supabase
NEXT_PUBLIC_SUPABASE_URL=https://xxx.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJ...
SUPABASE_SERVICE_ROLE_KEY=eyJ...

# Stripe
NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=pk_live_...
STRIPE_SECRET_KEY=sk_live_...
STRIPE_WEBHOOK_SECRET=whsec_...

# Cloudflare R2
R2_ACCOUNT_ID=...
R2_ACCESS_KEY_ID=...
R2_SECRET_ACCESS_KEY=...
R2_BUCKET_NAME=vault-media
R2_PUBLIC_DOMAIN=https://media.yourdomain.com
R2_ENDPOINT=https://xxx.r2.cloudflarestorage.com

# Mux
MUX_TOKEN_ID=...
MUX_TOKEN_SECRET=...
MUX_WEBHOOK_SECRET=...

# App
NEXT_PUBLIC_APP_URL=https://yourdomain.com
NEXT_PUBLIC_APP_NAME=VAULT
ADMIN_USER_ID=user_...  # Your Clerk user ID
```

---

## Deployment (Vercel)

```bash
# Install Vercel CLI
npm install -g vercel

# Deploy
vercel --prod
```

Or connect GitHub repo in Vercel dashboard for automatic deploys.

**Vercel settings:**
- Framework: Next.js
- Build command: `npm run build`
- Output directory: `.next`
- Add all environment variables in Vercel dashboard

**Stripe webhook production setup:**
```bash
# In Stripe dashboard, add webhook endpoint:
# https://yourdomain.com/api/webhook
# Events: checkout.session.completed, payment_intent.payment_failed
```

---

## Admin Access

After deploying:
1. Sign up on your site with your email
2. Copy your Clerk User ID from Clerk dashboard
3. Set `ADMIN_USER_ID=user_xxxxx` in environment
4. Redeploy
5. Visit `/admin` — only you can access it

---

## Uploading Content

1. Go to `/admin/upload`
2. Drag & drop image or video file
3. Set title, price (coins), tags
4. Toggle Featured / Premium flags
5. Click Upload

**Pricing guide:**
- Images: 10–50 coins (€0.10–€0.50)
- Short videos: 30–100 coins
- Premium videos: 100–500 coins

---

## Coin System

| Package | Coins | Price | Per Coin |
|---------|-------|-------|----------|
| Starter | 100 | €1.00 | €0.010 |
| Popular | 300 | €2.80 | €0.009 |
| Premium | 1000 | €8.50 | €0.0085 |

100 coins = €1 face value. Packages offer slight discounts to encourage larger purchases.

---

## Security Features

- **Signed URLs**: All media served via time-limited R2 signed URLs (no direct hotlinking)
- **RLS**: Supabase Row Level Security ensures users only see their own data
- **Atomic transactions**: Coin deduction uses PostgreSQL function with row locking
- **Admin guard**: Middleware checks Clerk user ID against `ADMIN_USER_ID`
- **Rate limiting**: Unlock endpoint limited to 10 requests/minute per user
- **No direct downloads**: `controlsList="nodownload"` on video + right-click prevention

---

## Folder Structure

```
src/
├── app/
│   ├── page.tsx              # Homepage
│   ├── explore/              # Browse page
│   ├── content/[id]/         # Content detail + unlock
│   ├── wallet/               # Wallet + recharge
│   ├── profile/              # User profile + unlocks
│   ├── login/                # Clerk sign-in
│   ├── signup/               # Clerk sign-up
│   ├── admin/                # Admin panel
│   │   ├── page.tsx          # Dashboard
│   │   ├── upload/           # Upload content
│   │   ├── users/            # User management
│   │   └── analytics/        # Analytics
│   └── api/
│       ├── unlock/           # POST: deduct coins + unlock
│       ├── recharge/         # POST: create Stripe session
│       ├── webhook/          # Stripe webhook handler
│       ├── clerk-webhook/    # Clerk user sync
│       ├── content/          # Thumbnail serving
│       └── admin/            # Admin APIs
├── components/
│   ├── layout/
│   │   └── SiteLayout.tsx    # Navbar + footer
│   ├── media/
│   │   ├── ContentCard.tsx   # Grid card
│   │   ├── ContentViewer.tsx # Image/video player
│   │   ├── UnlockButton.tsx  # Unlock CTA + modal
│   │   ├── ExploreGrid.tsx   # Server-rendered grid
│   │   └── ExploreFilters.tsx
│   ├── wallet/
│   │   ├── RechargePackages.tsx
│   │   └── TransactionHistory.tsx
│   └── admin/
│       ├── AdminLayout.tsx   # Sidebar layout
│       ├── StatCard.tsx
│       ├── RevenueChart.tsx
│       └── UploadForm.tsx
├── lib/
│   ├── supabase.ts           # DB client + helpers
│   ├── stripe.ts             # Stripe + recharge packages
│   ├── r2.ts                 # Cloudflare R2 signed URLs
│   └── utils.ts              # Shared utilities
├── types/
│   └── index.ts              # All TypeScript types
├── styles/
│   └── globals.css           # Design system + animations
└── middleware.ts             # Auth + admin protection

supabase/
└── migrations/
    └── 001_schema.sql        # Complete DB schema
```

---

## Scaling Plan

**Phase 1 (0–1K users):** Vercel hobby, Supabase free tier, Stripe test mode.

**Phase 2 (1K–10K users):**
- Vercel Pro (edge functions, better bandwidth)
- Supabase Pro (more connections, daily backups)
- Add Redis (Upstash) for rate limiting
- Cloudflare CDN for thumbnails

**Phase 3 (10K+ users):**
- Supabase connection pooling (PgBouncer)
- Dedicated Mux plan for video
- Split read/write DB connections
- Analytics pipeline (Posthog or custom)

---

## Monetization Optimization Tips

1. **Pricing psychology**: Keep images cheap (5–15 coins) to reduce friction on first unlock
2. **Featured content**: Tease premium items on homepage to drive wallet recharges
3. **Bundle pressure**: The 1000-coin package saves 15% — always show savings clearly  
4. **Urgency**: "X people unlocked this today" social proof on content pages
5. **Email capture**: Offer 10 free coins on signup (configurable in admin_settings)
6. **Recharge prompt**: If user views 3 locked items without balance, auto-show recharge modal
