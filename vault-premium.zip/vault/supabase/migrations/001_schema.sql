-- ═══════════════════════════════════════════════════════════════════
-- VAULT — Complete Database Schema
-- ═══════════════════════════════════════════════════════════════════

-- Enable required extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pg_trgm";

-- ─────────────────────────────────────────────────────────────────
-- USERS
-- Synced from Clerk via webhook. clerk_id is the primary reference.
-- ─────────────────────────────────────────────────────────────────
CREATE TABLE users (
  id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  clerk_id      TEXT UNIQUE NOT NULL,
  email         TEXT UNIQUE NOT NULL,
  username      TEXT UNIQUE,
  display_name  TEXT,
  avatar_url    TEXT,
  is_admin      BOOLEAN NOT NULL DEFAULT false,
  is_banned     BOOLEAN NOT NULL DEFAULT false,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  last_seen_at  TIMESTAMPTZ
);

CREATE INDEX idx_users_clerk_id ON users(clerk_id);
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_is_admin ON users(is_admin) WHERE is_admin = true;

-- ─────────────────────────────────────────────────────────────────
-- WALLET
-- One wallet per user. Balance in coins (100 coins = €1).
-- ─────────────────────────────────────────────────────────────────
CREATE TABLE wallet (
  id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id       UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  balance       INTEGER NOT NULL DEFAULT 0 CHECK (balance >= 0),
  lifetime_spent INTEGER NOT NULL DEFAULT 0,
  lifetime_added INTEGER NOT NULL DEFAULT 0,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(user_id)
);

CREATE INDEX idx_wallet_user_id ON wallet(user_id);

-- ─────────────────────────────────────────────────────────────────
-- WALLET TRANSACTIONS
-- Every debit/credit recorded here.
-- ─────────────────────────────────────────────────────────────────
CREATE TYPE transaction_type AS ENUM (
  'recharge',     -- user bought coins
  'unlock',       -- user spent coins on content
  'refund',       -- admin issued refund
  'bonus'         -- admin gave free coins
);

CREATE TABLE wallet_transactions (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  wallet_id       UUID NOT NULL REFERENCES wallet(id) ON DELETE CASCADE,
  user_id         UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  type            transaction_type NOT NULL,
  amount          INTEGER NOT NULL,           -- positive = credit, negative = debit
  balance_before  INTEGER NOT NULL,
  balance_after   INTEGER NOT NULL,
  description     TEXT,
  reference_id    UUID,                       -- content_id or payment_id
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_wallet_transactions_user_id ON wallet_transactions(user_id);
CREATE INDEX idx_wallet_transactions_wallet_id ON wallet_transactions(wallet_id);
CREATE INDEX idx_wallet_transactions_created_at ON wallet_transactions(created_at DESC);
CREATE INDEX idx_wallet_transactions_type ON wallet_transactions(type);

-- ─────────────────────────────────────────────────────────────────
-- PAYMENTS (Stripe charges for wallet recharges)
-- ─────────────────────────────────────────────────────────────────
CREATE TYPE payment_status AS ENUM (
  'pending',
  'succeeded',
  'failed',
  'refunded'
);

CREATE TABLE payments (
  id                    UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id               UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  stripe_payment_intent TEXT UNIQUE NOT NULL,
  stripe_session_id     TEXT,
  amount_eur_cents      INTEGER NOT NULL,       -- amount in euro cents
  coins_purchased       INTEGER NOT NULL,
  status                payment_status NOT NULL DEFAULT 'pending',
  metadata              JSONB DEFAULT '{}',
  created_at            TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at            TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_payments_user_id ON payments(user_id);
CREATE INDEX idx_payments_stripe_intent ON payments(stripe_payment_intent);
CREATE INDEX idx_payments_status ON payments(status);
CREATE INDEX idx_payments_created_at ON payments(created_at DESC);

-- ─────────────────────────────────────────────────────────────────
-- CONTENT
-- Images and videos uploaded by admin only.
-- ─────────────────────────────────────────────────────────────────
CREATE TYPE content_type AS ENUM ('image', 'video');
CREATE TYPE content_status AS ENUM ('draft', 'published', 'archived');

CREATE TABLE content (
  id                UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  type              content_type NOT NULL,
  status            content_status NOT NULL DEFAULT 'draft',
  title             TEXT NOT NULL,
  description       TEXT,
  coin_price        INTEGER NOT NULL DEFAULT 10 CHECK (coin_price >= 0),
  is_featured       BOOLEAN NOT NULL DEFAULT false,
  is_premium        BOOLEAN NOT NULL DEFAULT false,

  -- R2 Storage
  storage_key       TEXT,                         -- R2 object key (full-res)
  thumbnail_key     TEXT,                         -- R2 thumbnail key
  blur_hash         TEXT,                         -- BlurHash for placeholder
  file_size_bytes   BIGINT,
  dimensions        JSONB,                        -- {width, height}

  -- Video specific (Mux)
  mux_asset_id      TEXT,
  mux_playback_id   TEXT,                         -- public playback for preview
  mux_playback_id_signed TEXT,                    -- signed playback for full
  duration_seconds  INTEGER,

  -- Stats (denormalized for performance)
  unlock_count      INTEGER NOT NULL DEFAULT 0,
  view_count        INTEGER NOT NULL DEFAULT 0,

  -- Tags for filtering
  tags              TEXT[] DEFAULT '{}',

  sort_order        INTEGER DEFAULT 0,
  created_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at        TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_content_status ON content(status);
CREATE INDEX idx_content_type ON content(type);
CREATE INDEX idx_content_featured ON content(is_featured) WHERE is_featured = true;
CREATE INDEX idx_content_premium ON content(is_premium);
CREATE INDEX idx_content_created_at ON content(created_at DESC);
CREATE INDEX idx_content_unlock_count ON content(unlock_count DESC);
CREATE INDEX idx_content_tags ON content USING gin(tags);

-- ─────────────────────────────────────────────────────────────────
-- UNLOCKED CONTENT
-- Permanent unlock record per user per content item.
-- ─────────────────────────────────────────────────────────────────
CREATE TABLE unlocked_content (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id         UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  content_id      UUID NOT NULL REFERENCES content(id) ON DELETE CASCADE,
  coins_spent     INTEGER NOT NULL,
  unlocked_at     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  last_viewed_at  TIMESTAMPTZ,
  view_count      INTEGER NOT NULL DEFAULT 0,
  UNIQUE(user_id, content_id)
);

CREATE INDEX idx_unlocked_user_id ON unlocked_content(user_id);
CREATE INDEX idx_unlocked_content_id ON unlocked_content(content_id);
CREATE INDEX idx_unlocked_user_content ON unlocked_content(user_id, content_id);
CREATE INDEX idx_unlocked_at ON unlocked_content(unlocked_at DESC);

-- ─────────────────────────────────────────────────────────────────
-- ANALYTICS (Content view/unlock events)
-- ─────────────────────────────────────────────────────────────────
CREATE TYPE analytics_event AS ENUM (
  'content_view',       -- user viewed content detail page
  'content_unlock',     -- user unlocked content
  'content_play',       -- video play event
  'page_view',          -- general page view
  'recharge_start',     -- user started recharge flow
  'recharge_complete'   -- user completed recharge
);

CREATE TABLE analytics (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id     UUID REFERENCES users(id) ON DELETE SET NULL,
  event       analytics_event NOT NULL,
  content_id  UUID REFERENCES content(id) ON DELETE SET NULL,
  metadata    JSONB DEFAULT '{}',
  ip_hash     TEXT,               -- hashed IP for dedup, never raw
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_analytics_event ON analytics(event);
CREATE INDEX idx_analytics_content_id ON analytics(content_id);
CREATE INDEX idx_analytics_user_id ON analytics(user_id);
CREATE INDEX idx_analytics_created_at ON analytics(created_at DESC);

-- ─────────────────────────────────────────────────────────────────
-- ADMIN SETTINGS (key-value store)
-- ─────────────────────────────────────────────────────────────────
CREATE TABLE admin_settings (
  key         TEXT PRIMARY KEY,
  value       JSONB NOT NULL,
  description TEXT,
  updated_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

INSERT INTO admin_settings (key, value, description) VALUES
  ('site_name', '"VAULT"', 'Website display name'),
  ('site_tagline', '"Premium Content, Unlocked."', 'Hero tagline'),
  ('default_image_price', '10', 'Default coin price for images'),
  ('default_video_price', '50', 'Default coin price for videos'),
  ('coins_per_euro', '100', 'Coin conversion rate'),
  ('recharge_packages', '[{"coins":100,"price_cents":100,"label":"Starter"},{"coins":300,"price_cents":280,"label":"Popular","badge":"Best Value"},{"coins":1000,"price_cents":850,"label":"Premium","badge":"Save 15%"}]', 'Recharge packages'),
  ('maintenance_mode', 'false', 'Put site in maintenance mode'),
  ('watermark_enabled', 'true', 'Add watermark to unlocked images');

-- ─────────────────────────────────────────────────────────────────
-- FUNCTIONS & TRIGGERS
-- ─────────────────────────────────────────────────────────────────

-- Auto-create wallet when user is created
CREATE OR REPLACE FUNCTION create_wallet_for_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO wallet (user_id) VALUES (NEW.id);
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE TRIGGER on_user_created
  AFTER INSERT ON users
  FOR EACH ROW EXECUTE FUNCTION create_wallet_for_user();

-- Update updated_at automatically
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER users_updated_at BEFORE UPDATE ON users
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

CREATE TRIGGER wallet_updated_at BEFORE UPDATE ON wallet
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

CREATE TRIGGER content_updated_at BEFORE UPDATE ON content
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

CREATE TRIGGER payments_updated_at BEFORE UPDATE ON payments
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

-- Increment content unlock_count atomically
CREATE OR REPLACE FUNCTION increment_unlock_count(p_content_id UUID)
RETURNS VOID AS $$
BEGIN
  UPDATE content SET unlock_count = unlock_count + 1 WHERE id = p_content_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Safe coin deduction (prevents race conditions / overdraft)
CREATE OR REPLACE FUNCTION deduct_coins(
  p_user_id UUID,
  p_amount INTEGER,
  p_content_id UUID,
  p_description TEXT
)
RETURNS TABLE(success BOOLEAN, new_balance INTEGER, error TEXT) AS $$
DECLARE
  v_wallet_id UUID;
  v_balance INTEGER;
  v_new_balance INTEGER;
BEGIN
  -- Lock the wallet row
  SELECT id, balance INTO v_wallet_id, v_balance
  FROM wallet
  WHERE user_id = p_user_id
  FOR UPDATE;

  IF NOT FOUND THEN
    RETURN QUERY SELECT false, 0, 'Wallet not found';
    RETURN;
  END IF;

  IF v_balance < p_amount THEN
    RETURN QUERY SELECT false, v_balance, 'Insufficient balance';
    RETURN;
  END IF;

  v_new_balance := v_balance - p_amount;

  -- Deduct from wallet
  UPDATE wallet
  SET balance = v_new_balance,
      lifetime_spent = lifetime_spent + p_amount,
      updated_at = NOW()
  WHERE id = v_wallet_id;

  -- Record transaction
  INSERT INTO wallet_transactions (
    wallet_id, user_id, type, amount,
    balance_before, balance_after, description, reference_id
  ) VALUES (
    v_wallet_id, p_user_id, 'unlock', -p_amount,
    v_balance, v_new_balance, p_description, p_content_id
  );

  -- Record unlock
  INSERT INTO unlocked_content (user_id, content_id, coins_spent)
  VALUES (p_user_id, p_content_id, p_amount)
  ON CONFLICT (user_id, content_id) DO NOTHING;

  -- Increment content unlock count
  PERFORM increment_unlock_count(p_content_id);

  RETURN QUERY SELECT true, v_new_balance, NULL::TEXT;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Add coins to wallet (called after Stripe webhook)
CREATE OR REPLACE FUNCTION add_coins(
  p_user_id UUID,
  p_amount INTEGER,
  p_payment_id UUID,
  p_description TEXT
)
RETURNS TABLE(success BOOLEAN, new_balance INTEGER) AS $$
DECLARE
  v_wallet_id UUID;
  v_balance INTEGER;
  v_new_balance INTEGER;
BEGIN
  SELECT id, balance INTO v_wallet_id, v_balance
  FROM wallet
  WHERE user_id = p_user_id
  FOR UPDATE;

  v_new_balance := v_balance + p_amount;

  UPDATE wallet
  SET balance = v_new_balance,
      lifetime_added = lifetime_added + p_amount,
      updated_at = NOW()
  WHERE id = v_wallet_id;

  INSERT INTO wallet_transactions (
    wallet_id, user_id, type, amount,
    balance_before, balance_after, description, reference_id
  ) VALUES (
    v_wallet_id, p_user_id, 'recharge', p_amount,
    v_balance, v_new_balance, p_description, p_payment_id
  );

  RETURN QUERY SELECT true, v_new_balance;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- ─────────────────────────────────────────────────────────────────
-- ROW LEVEL SECURITY
-- ─────────────────────────────────────────────────────────────────

ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE wallet ENABLE ROW LEVEL SECURITY;
ALTER TABLE wallet_transactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE payments ENABLE ROW LEVEL SECURITY;
ALTER TABLE content ENABLE ROW LEVEL SECURITY;
ALTER TABLE unlocked_content ENABLE ROW LEVEL SECURITY;
ALTER TABLE analytics ENABLE ROW LEVEL SECURITY;

-- Users: can read/update own record
CREATE POLICY "users_read_own" ON users FOR SELECT USING (clerk_id = auth.uid()::TEXT);
CREATE POLICY "users_update_own" ON users FOR UPDATE USING (clerk_id = auth.uid()::TEXT);

-- Wallet: users see own wallet only
CREATE POLICY "wallet_read_own" ON wallet FOR SELECT
  USING (user_id IN (SELECT id FROM users WHERE clerk_id = auth.uid()::TEXT));

-- Transactions: users see own only
CREATE POLICY "transactions_read_own" ON wallet_transactions FOR SELECT
  USING (user_id IN (SELECT id FROM users WHERE clerk_id = auth.uid()::TEXT));

-- Payments: users see own only
CREATE POLICY "payments_read_own" ON payments FOR SELECT
  USING (user_id IN (SELECT id FROM users WHERE clerk_id = auth.uid()::TEXT));

-- Content: published content is public to browse; drafts admin-only
CREATE POLICY "content_read_published" ON content FOR SELECT
  USING (status = 'published');

-- Unlocked content: users see own unlocks
CREATE POLICY "unlocked_read_own" ON unlocked_content FOR SELECT
  USING (user_id IN (SELECT id FROM users WHERE clerk_id = auth.uid()::TEXT));

-- ─────────────────────────────────────────────────────────────────
-- VIEWS
-- ─────────────────────────────────────────────────────────────────

-- Content with user unlock status (used in explore page)
CREATE OR REPLACE VIEW content_with_unlock_status AS
SELECT
  c.*,
  uc.unlocked_at,
  uc.view_count AS user_view_count,
  CASE WHEN uc.id IS NOT NULL THEN true ELSE false END AS is_unlocked
FROM content c
LEFT JOIN unlocked_content uc ON c.id = uc.content_id;

-- Revenue summary by day
CREATE OR REPLACE VIEW daily_revenue AS
SELECT
  DATE_TRUNC('day', created_at) AS day,
  COUNT(*) AS payment_count,
  SUM(amount_eur_cents) AS total_cents,
  SUM(coins_purchased) AS total_coins
FROM payments
WHERE status = 'succeeded'
GROUP BY 1
ORDER BY 1 DESC;

-- Top content by revenue
CREATE OR REPLACE VIEW top_content_by_revenue AS
SELECT
  c.id,
  c.title,
  c.type,
  c.coin_price,
  c.unlock_count,
  (c.unlock_count * c.coin_price) AS total_coins_earned
FROM content c
WHERE c.status = 'published'
ORDER BY total_coins_earned DESC;
